<!-- <?php
//session_destroy();
//header("location:login.php");
?> -->

<?php 
ob_start();
session_start(); 
unset($_SESSION['customer']);
header("location:login.php");
?>