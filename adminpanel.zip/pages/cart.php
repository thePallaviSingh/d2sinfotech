<?php 
include_once("header.php");
?>
<?php 
 
    if (isset($_POST["add"])){
         $pid = base64_decode($_GET["id"]);

        if (isset($_SESSION["cart"])){
            $item_array_id = array_column($_SESSION["cart"],"product_id");
            if (!in_array($pid,$item_array_id)){
                $count = count($_SESSION["cart"]);
                $item_array = array(
                    'product_id' => $pid,
                    'item_name' => $_POST["hidden_name"],
                    'product_img'=>$_POST["product_img"],
                    'product_price' => $_POST["hidden_price"],
                    'item_quantity' => $_POST["quantity"],
                ); 
                $_SESSION["cart"][$count] = $item_array;

                echo '<script>alert("Product is Added to Cart!!")</script>';
                echo '<script>window.location="index.php"</script>';
            }else{
                echo '<script>alert("Product is already Added to Cart")</script>';
                echo '<script>window.location="index.php"</script>';
            }
        }else{
            $item_array = array(
                'product_id' => $pid,
                'item_name' => $_POST["hidden_name"],
                'product_img'=>$_POST["product_img"],
                'product_price' => $_POST["hidden_price"],
                'item_quantity' => $_POST["quantity"],
            );

            $_SESSION["cart"][0] = $item_array;
        }
    }
    if (isset($_GET["action"])){
        if ($_GET["action"] == "delete"){
             $pid = base64_decode($_GET["id"]);
            foreach ($_SESSION["cart"] as $keys => $value){
                if ($value["product_id"] == $pid){
                    unset($_SESSION["cart"][$keys]);
                    echo '<script>alert("Product has been Removed...!")</script>';
                    echo '<script>window.location="cart.php"</script>';
                }
            }
        }
    }

  
 

?>
  <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Shopping Cart</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
    <!--breadcrumbs area end-->
    
     <!--shopping cart area start -->
    <div class="shopping_cart_area mt-60">
        <div class="container">  
            <form action="#"> 
                <div class="row">
                    <div class="col-12">
                      <form action="" method="POST">
                        <div class="table_desc">
                            <div class="cart_page table-responsive">
                                <table>
                            <thead>
                                <tr>
                                    <th class="product_remove">Delete</th>
                                    <th class="product_thumb">Image</th>
                                    <th class="product_name">Product</th>
                                    <th class="product-price">Price</th>
                                    <th class="product_quantity">Quantity</th>
                                    <th class="product_total">Total</th>
                                </tr>
                            </thead>
                            <tbody>  
                                <?php  if(!empty($_SESSION["cart"])){
                                    $total = 0;
                                    foreach ($_SESSION["cart"] as $key => $value) {
                                        ?>
                                <tr id="<?=$key?>">
                                   <td class="product_remove"><a href="cart.php?action=delete&id=<?= base64_encode($value["product_id"]); ?>"><i class="fa fa-trash-o"></i></a></td>
                                    <td class="product_thumb"><a href="#"><img src="../upload_data/<?=$value["product_img"]; ?>" alt=""></a></td>
                                    <td class="product_name"><a href="#"><?php echo $value["item_name"]; ?></a></td>
                                    <td class="product-price"><?php echo $value["product_price"]; ?></td>
                                    <td class="product_quantity"><label>Quantity</label>
                                       <input type="hidden" name="product_id" value="<?php echo $value["product_id"] ?>">
                                       <input type="hidden" name="product_name" value="<?php echo $value["item_name"]; ?>">

                                     <input min="1" name="qty" max="10" value="<?php echo $value["item_quantity"]; ?>" type="number">
                                     
                                     <a href="cart.php?action=update&id=<?=$key;?>"><i class="fa fa-save"></i></a></td>

                                    <td class="product_total"><?php echo number_format($value["item_quantity"] * $value["product_price"], 2); ?></td>
                                </tr>
                                <?php
                                 $total = $total + ($value["item_quantity"] * $value["product_price"]);
                                }
                                 ?>
                                 <?php
                    }
                ?>
                            </tbody>
                        </table>   
                            </div>  
                            <div class="cart_submit">
                                <button type="submit" name="form1">update cart</button>
                            </div>      
                        </div>
                      </form>
                     </div>
                 </div>
                 <!--coupon code area start-->
                <div class="coupon_area">
                    <div class="row">
                        <!-- <div class="col-lg-6 col-md-6">
                            <div class="coupon_code left">
                                <h3>Coupon</h3>
                                <div class="coupon_inner">   
                                    <p>Enter your coupon code if you have one.</p>                                
                                    <input placeholder="Coupon code" type="text">
                                    <button type="submit">Apply coupon</button>
                                </div>    
                            </div>
                        </div> -->
                        <div class="col-lg-12 col-md-12">
                            <div class="coupon_code right">
                                <h3>Cart Totals</h3>
                                <div class="coupon_inner">
                                   <div class="cart_subtotal">
                                       <p>Subtotal</p>
                                       <p class="cart_amount"><?=$total?></p>
                                   </div> 
                                   <div class="cart_subtotal">
                                       <p>Total</p>
                                       <p class="cart_amount"><?=$total?></p>
                                   </div>
                                   <div class="checkout_btn">
                                       <a href="checkout.php">Proceed to Checkout</a>
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--coupon code area end-->
            </form> 
        </div>     
    </div>
     <!--shopping cart area end -->
<?php 
include_once("footer.php");
 ?>