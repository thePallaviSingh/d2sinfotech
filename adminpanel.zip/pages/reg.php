<?php
include_once("header.php");
include_once("connection.php");
?>
<style>
    .form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #337ab7;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
}
</style>
<!--Validation-->
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
        <script>
    function formvalidate(cust_name,cust_email) {
               text=/^[a-z A-Z]+$/.test(cust_name);
               if (text==false) {
                   alert('Enter valid name..!!');
                   return false;
               }
               
               text=/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/.test(cust_email)
               if (text==false) {
                   alert('Enter valid email id..!!');
                   return false;
               }
    var phone = $('input[name=" cust_phone"]').val(),
          intRegex = /[0-9 -()+]+$/;
           if((phone.length < 10) || (!intRegex.test(phone)))
            {
     alert('Please enter a valid phone number.');
     return false;
           }
               
               return true;
            }
            
            $(document).ready(function(){
               $('#register').validate({
                   rules: {
                       "cust_name":{
                           required: true,
                       },
                       "cust_email":{
                           required: true,
                       },
                       "mob":{
                           required: true,
                           digits: true,
                           maxlength: 10,
                           minlength: 10,
                       },
                       
                      
            
                       "add":{
                           required: true,
                       },
                       "password":{
                           required: true,
                       }
                   }
                   
               });
            });
            
</script>
<!--register area start-->
<div class="col-lg-2 col-md-2"></div>
<div class="col-lg-8 col-md-8">
    <h2>Register</h2>
    <div class="col-md-12">
        <form action="" method="post" id="register" onsubmit="return formvalidate(name.value,mail.value,speciality.value)">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-12">
                    <div class="col-md-6 form-group">
                        <label for="">Full name *</label>
                        <input type="text" class="form-control" name="cust_name" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Email Id *</label>
                        <input type="email" class="form-control" name="cust_email" value="" required>
                    </div>
                    <div class="col-md-12 form-group">
                        <label for="">Address *</label>
                        <textarea name="cust_address" class="form-control" cols="30" rows="10" style="height:70px;" required></textarea>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Country *</label>
                        <select id="cust_country" name="cust_country"  class="form-control select2" required type="text">
                            
                            <option value="name">--country--</option>
                            <?php
                            $sql="select country_id,country_name from tbl_country";
                            $query=mysqli_query($con,$sql);
                            while($row=mysqli_fetch_assoc($query))
                            { ?>
                            <option value="<?php echo $row['country_name'];?>"><?php echo $row['country_name'];?></option>
                            <?php } ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6 form-group">
                        <label for="">City *</label>
                        <input type="text" class="form-control" name="cust_city" value="" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Phone Number *</label>
                        <input type="text" class="form-control" name="cust_phone" value="" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">State *</label>
                        <input type="text" class="form-control" name="cust_state" value="" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Pin code*</label>
                        <input type="text" class="form-control" name="cust_zip" value="" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Password *</label>
                        <input type="password" class="form-control" name="cust_password"required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for=""></label>
                        <input type="submit" class="btn btn-primary" value="Register" name="form1">
                        
                    </div>
                    <a href="login.php">Already register then login?</a>
                </div>
            </div>
        </form>
    </div>
    
</div>
<div class="col-lg-2 col-md-2"></div>
<!--register area end-->
<?php
if(isset($_POST['form1']))
{
  $token = md5(time());
$sql="INSERT INTO `tbl_customer`(cust_name,cust_email, cust_phone,cust_country, cust_address, cust_city, cust_state, cust_zip, cust_password, cust_token) VALUES ('".$_POST['cust_name']."','".$_POST['cust_email']."','".$_POST['cust_phone']."','".$_POST['cust_country']."','".$_POST['cust_address']."','".$_POST['cust_city']."','".$_POST['cust_state']."','".$_POST['cust_zip']."','".$_POST['cust_password']."','".$token."')";
$result=mysqli_query($con,$sql);
if($result == 1)
{
?>
<script>
alert("details submitted successfully!!!!");
window.location.assign("login.php");
</script>
<?php
}else{
alert("not submitted");
}
}
?>