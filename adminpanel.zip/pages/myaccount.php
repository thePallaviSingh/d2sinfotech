<?php
include_once("header.php");
include_once("connection.php");
?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
<div class="container">
<div class="row">
<div class="col-12">
    <div class="breadcrumb_content">
        <ul>
            <li><a href="index.php">home</a></li>
            <li>My account</li>
        </ul>
    </div>
</div>
</div>
</div>
</div>
<!--breadcrumbs area end-->
<!-- my account start  -->
<section class="main_content_area">
<div class="container">
<div class="account_dashboard">
<div class="row">
    <div class="col-sm-12 col-md-3 col-lg-3">
        <!-- Nav tabs -->
        <div class="dashboard_tab_button">
            <ul role="tablist" class="nav flex-column dashboard-list">
                <!--<li><a href="#dashboard" data-toggle="tab" class="nav-link active">Dashboard</a></li>-->
                <li> <a href="#orders" data-toggle="tab" class="nav-link">Orders</a></li>
                <li><a href="#downloads" data-toggle="tab" class="nav-link">Downloads</a></li>
                <li><a href="#address" data-toggle="tab" class="nav-link">Addresses</a></li>
                <li><a href="#account-details" data-toggle="tab" class="nav-link">Account details</a></li>
                <li><a href="login.php" class="nav-link">logout</a></li>
            </ul>
        </div>
    </div>
    <div class="col-sm-12 col-md-9 col-lg-9">
        <!-- Tab panes -->
        <div class="tab-content dashboard_content">
            <div class="tab-pane fade show active" id="dashboard">
                <h3>Dashboard </h3>
                <p>From your account dashboard. you can easily check &amp; view your <a href="#">recent orders</a>, manage your <a href="#">shipping and billing addresses</a> and <a href="#">Edit your password and account details.</a></p>
            </div>
            <div class="tab-pane fade" id="orders">
                <h3>Orders</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>S.NO</th>
                                <th>Product Name</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Payment Id</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                         $sql="SELECT o.product_id,o.product_name,p.payment_date,p.shipping_status,o.quantity,o.unit_price,o.payment_id FROM tbl_order o JOIN tbl_payment p ON p.payment_id=o.payment_id WHERE customer_id = '".$_SESSION['customer']['cust_id']."'";
                                     $query=mysqli_query($con,$sql);
                                     $n =1;
                                   while($row=mysqli_fetch_assoc($query))
                                      { 
                                      if(!empty($row['product_name'])){ ?>
                                         <tr>
                                        <td><?=$n;?></td>
                                        <td><?=$row['product_name']?></td>
                                        <td><?=date('d-m-Y',strtotime($row['payment_date']));?></td>
                                        <td><span class="success"><?=$row['shipping_status']?></span></td>
                                        <td><?=$row['unit_price'];?></td>
                                        <td><?=$row['payment_id'];?></td>
                                    </tr>
                                      <?php }else{?> 
                                      <tr> 
                                                <td style="width:90px">Ruh ohes! The Row was Empty!</td>
                                                ';
                                           <?php } ?>

                           
                            <?php $n++; } ?> 
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="downloads">
                <h3>Downloads</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Downloads</th>
                                <th>Expires</th>
                                <th>Download</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Shopnovilla - Free Real Estate PSD Template</td>
                                <td>May 10, 2018</td>
                                <td><span class="danger">Expired</span></td>
                                <td><a href="#" class="view">Click Here To Download Your File</a></td>
                            </tr>
                            <tr>
                                <td>Organic - ecommerce html template</td>
                                <td>Sep 11, 2018</td>
                                <td>Never</td>
                                <td><a href="#" class="view">Click Here To Download Your File</a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php 
                $query="select * from tbl_customer where cust_token='".$_SESSION['customer']['cust_token']."'";
                $q=mysqli_query($con,$query) or die(mysqli_error($con));
                foreach($q as $row) {
                      $cust_b_name = $row['cust_b_name'];
                      $cust_b_phone = $row['cust_b_phone'];
                      $cust_b_country = $row['cust_b_country']; 
                      $cust_b_address = $row['cust_b_address'];
                      $cust_b_city = $row['cust_b_city'];
                      $cust_b_state = $row['cust_b_state'];
                      $cust_b_zip = $row['cust_b_zip'];
                      $cust_b_name = $row['cust_b_name'];

                      $cust_s_name = $row['cust_s_name'];
                      $cust_s_phone = $row['cust_s_phone'];
                      $cust_s_country = $row['cust_s_country']; 
                      $cust_s_address = $row['cust_s_address'];
                      $cust_s_city = $row['cust_s_city'];
                      $cust_s_state = $row['cust_s_state'];
                      $cust_s_zip = $row['cust_s_zip'];
                      $cust_s_name = $row['cust_s_name'];
                }  
            ?>
            <?php($_SESSION['customer'])?>
            <div class="tab-pane" id="address">
                <div class="row">
                    <form action="" method="post">
                        <div class="col-md-6">
                            <h3>Update Billing Address</h3>
                            <div class="form-group">
                                <label for="">Full Name</label>
                                <input type="text" class="form-control" name="cust_b_name" value="<?=$cust_b_name?>">
                                <input type="hidden" name="cust_token" value="<?=$_SESSION['customer']['cust_token']?>">
                            </div> 
                            <div class="form-group">
                                <label for="">Phone Number</label>
                                <input type="text" class="form-control" name="cust_b_phone" value="<?=$cust_b_phone?>">
                            </div>
                            <div class="form-group">
                                <label for="">Country</label>  
                                     <input type="text" class="form-control" name="cust_b_country" value="<?=$cust_b_country?>"> 
                            </div>
                            <div class="form-group">
                                <label for="">Address</label>
                                <textarea name="cust_b_address" class="form-control" cols="30" rows="10" style="height:100px;"><?=$cust_b_address?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="">City</label>
                                <input type="text" class="form-control" name="cust_b_city" value="<?=$cust_b_city?>">
                            </div>
                            <div class="form-group">
                                <label for="">State</label>
                                <input type="text" class="form-control" name="cust_b_state" value="<?=$cust_b_state?>">
                            </div>
                            <div class="form-group">
                                <label for="">Zip Code</label>
                                <input type="text" class="form-control" name="cust_b_zip" value="<?=$cust_b_zip?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h3>Update Shipping Address</h3>
                            <div class="form-group">
                                <label for="">Full Name</label>
                                <input type="text" class="form-control" name="cust_s_name" value="<?=$cust_s_name?>">
                            </div> 
                            <div class="form-group">
                                <label for="">Phone Number</label>
                                <input type="text" class="form-control" name="cust_s_phone" value="<?=$cust_s_phone?>">
                            </div>
                            <div class="form-group">
                                <label for="">Country</label>
                                 <input type="text" class="form-control" name="cust_s_country" value="<?=$cust_s_country?>">
                                 
                            </div>
                            <div class="form-group">
                                <label for="">Address</label>
                                <textarea name="cust_s_address" class="form-control" cols="30" rows="10" style="height:100px;"><?=$cust_s_address?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="">City</label>
                                <input type="text" class="form-control" name="cust_s_city" value="<?=$cust_s_city?>">
                            </div>
                            <div class="form-group">
                                <label for="">State</label>
                                <input type="text" class="form-control" name="cust_s_state" value="<?=$cust_s_state?>">
                            </div>
                            <div class="form-group">
                                <label for="">Zip Code</label>
                                <input type="text" class="form-control" name="cust_s_zip" value="<?=$cust_s_zip?>">
                            </div>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Update" name="address">
                    </form>
                </div>
            </div>
            <div class="tab-pane fade" id="account-details">
                <h3>Account details </h3>
                <div class="login">
                    <div class="login_form_container">
                        <div class="account_login_form">
                            <form action="#">
                                <p>Already have an account? <a href="#">Log in instead!</a></p>
                                <div class="input-radio">
                                    <span class="custom-radio"><input type="radio" value="1" name="id_gender"> Mr.</span>
                                    <span class="custom-radio"><input type="radio" value="1" name="id_gender"> Mrs.</span>
                                </div> <br>
                                <label>First Name</label>
                                <input type="text" name="first-name">
                                <label>Last Name</label>
                                <input type="text" name="last-name">
                                <label>Email</label>
                                <input type="text" name="email-name">
                                <label>Password</label>
                                <input type="password" name="user-password">
                                <label>Birthdate</label>
                                <input type="text" placeholder="MM/DD/YYYY" value="" name="birthday">
                                <span class="example">
                                    (E.g.: 05/31/1970)
                                </span>
                                <br>
                                <span class="custom_checkbox">
                                    <input type="checkbox" value="1" name="optin">
                                    <label>Receive offers from our partners</label>
                                </span>
                                <br>
                                <span class="custom_checkbox">
                                    <input type="checkbox" value="1" name="newsletter">
                                    <label>Sign up for our newsletter<br><em>You may unsubscribe at any moment. For that purpose, please find our contact info in the legal notice.</em></label>
                                </span>
                                <div class="save_button primary_btn default_button">
                                    <button type="submit">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</section>
<!-- my account end   -->

<?php
if(isset($_POST['address']))
{
$sql="UPDATE `tbl_customer` SET cust_b_name='".$_POST['cust_b_name']."',cust_b_phone='".$_POST['cust_b_phone']."',cust_b_country='".$_POST['cust_b_country']."',cust_b_address='".$_POST['cust_b_address']."',cust_b_city='".$_POST['cust_b_city']."',`cust_b_state`='".$_POST['cust_b_state']."',`cust_b_zip`='".$_POST['cust_b_zip']."',cust_s_name='".$_POST['cust_s_name']."',cust_s_phone='".$_POST['cust_s_phone']."',cust_s_country='".$_POST['cust_s_country']."',cust_s_address='".$_POST['cust_s_address']."',cust_s_city='".$_POST['cust_s_city']."',cust_s_state='".$_POST['cust_s_state']."',cust_s_zip='".$_POST['cust_s_zip']."' WHERE cust_token='".$_POST['cust_token']."'";

$result=mysqli_query($con,$sql);
if($result == 1)
{
?>
<script>
alert("update successfully!!!!");
window.location.assign("checkout.php");
</script>
<?php
}else{
alert("not submitted");
}
}
?>
<?php
include_once("footer.php");
?>