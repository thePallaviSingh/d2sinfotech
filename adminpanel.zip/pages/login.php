<?php
include_once("header.php");
?>
 <!--breadcrumbs area end--> 
    <!-- customer login start -->
    <div class="customer_login mt-60">
        <div class="container">
            <div class="row">
               <!--login area start-->
                <div class="col-lg-12 col-md-12">
                    <div class="account_form">
                        <h2>login</h2>
                       <form action="../backend/login.php" method="POST">
                            <p>   
                                <label>Username or email <span>*</span></label>
                                <input type="text" name="email">
                             </p>
                             <p>   
                                <label>Passwords <span>*</span></label>
                                <input type="password" name="password">
                             </p>   
                            <div class="login_submit">
                               <a href="forgotpassword.php">Lost your password?</a> 
                               <a href="reg.php">If not register then register?</a>
                                <label for="remember">
                                    <input id="remember" type="checkbox">
                                    Remember me
                                </label>
                                <button type="submit" name="submit">login</button>
                                
                            </div>

                        </form>

                     </div>    
                </div>
                <!--login area start-->

                
            </div>
        </div>    
    </div>
     
    <!-- customer login end -->
<?php
include_once("footer.php");
?>