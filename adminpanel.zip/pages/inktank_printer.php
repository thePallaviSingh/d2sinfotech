<?php
include_once("header.php");
include_once("connection.php");
?>
<div class="text-anim">
  <div id="container-anim">
    <div id="flip">
      <div>
        <div>Ink printer</div>
      </div>
    </div>
  </div>
</div>
<div class="row colrow">
  <!-- product -->
  <?php 
  $sql="select product_name.id, product_category.product_category,product_subcategory.product_subcategory,product_name.product_name,product_name.product_detail,product_name.product_price,product_name.product_image from ((product_name inner join product_subcategory on product_name.subcategory_id=product_subcategory.subcategory_id)INNER JOIN product_category on product_name.category_id=product_category.category_id)";
  $result= mysqli_query($con,$sql);
  while($row=mysqli_fetch_array($result)) {
  ?>
  <div class="col-md-4 colrow1">
    <div class="card"> 
     <!--  <center><img src="assets/img/product/ink1.jpg" class="printercardimage"></center> -->
    <center><img src="../upload_data/<?php echo $row['product_image'];?>" class="printercardimage" alt="../upload_data/<?php echo $row['product_image'];?>"></center>
      <h4><?php echo $row['product_name'];?></h4>
      <ul class="a">
        <?php echo $row['product_detail'];?>
        <!-- <li>Rechargeble battery option</li>
        <li>Print resolution up to 5760dpi</li>
        <li>Lightweight and portable</li> -->
      </ul>
      <p class="pricing"><?php echo $row['product_price'];?></p>
      <button type="button" class="btn btn-primary"data-toggle="modal" data-target="#myModal<?=$key?>">SHOP NOW</button>
      <div class="modal fade" id="myModal<?=$key?>" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>
            </div>
            <div class="modal-body">
              <div class="row">
                <div class="col-md-4">
                  <img src="assets/img/product/ink1.jpg" class="printercardimage" style="width:182px" "height:30px" "margin-top:-5px">
                </div>
                <div class="col-md-8">
                  <center><h4><?php echo $row['product_name'];?></h4></center>
                  EcoTank L3116 Multifunction InkTank Printer<br>
                  <ul class="a">
                    <li>Print, scan and copy functions</li>
                    <li>Borderless Printing...</li>
                    
                  </ul>
                </div>
              </div>
              <p> Rs. 18,299 *<br>
                price inclusive of all taxes<br>
              Free shipping on order above Rs.599</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
<?php }?>

  <!--product -->
</div>
<?php
include_once("footer.php");
?>