<?php
include_once("header.php");
?>
 <!--breadcrumbs area end--> 
    <!-- customer login start -->
    <div class="customer_login mt-60">
        <div class="container">
            <div class="row">
               <!--login area start-->
                <div class="col-lg-12 col-md-12">
                    <div class="account_form">
                        <h2>Forgot Password</h2>
                       <form action="../backend/forgot.php" method="POST">
                            <p>   
                                <label>Email <span>*</span></label>
                                <input type="text" name="email">
                             </p>   
                            <div class="login_submit">  
                               <a href="reg.php">If not register then register?</a> 
                                <button type="submit" name="forgotpwd">login</button>
                                
                            </div>

                        </form>

                     </div>    
                </div>
                <!--login area start-->

                
            </div>
        </div>    
    </div>
     
    <!-- customer login end -->
<?php
include_once("footer.php");
?>