
<?php
include_once("header.php");
?>
<body>
   <div id="slidy-container">
  <figure id="slidy">
    <img src="assets/img/slider/sliderbanner3.jpg" alt="eyes" >
    <img src="assets/img/slider/sliderbanner5.jpg" alt="lou" >
    <img src="assets/img/slider/sliderbanner2.jpg" alt="lucie-2" >
    <img src="assets/img/slider/sliderbanner6.jpg" alt="lucie" >
  </figure>
</div> 
 
<center><button type="button" class="btn btn-primary indexbtn">Our Products</button></center>

    <div class="row colrow">
       <?php  
  $sql="SELECT p.id,p.product_name,p.product_detail,p.product_price,p.product_image,s.product_subcategory,c.product_category FROM product_name p JOIN product_category c ON c.category_id=p.category_id   JOIN product_subcategory s ON s.subcategory_id=p.subcategory_id";
  $result= mysqli_query($con,$sql);
  while($row=mysqli_fetch_array($result)) {
    $key =rand(100,999);
  ?>
<div class="col-md-4 col-xs-12">
     <div class="card">
    
    <center><img src="../upload_data/<?php echo $row['product_image'];?>" class="printercardimage" alt="../upload_data/<?php echo $row['product_image'];?>"></center>
      <h4><?php echo $row['product_name'];?></h4>
      <ul class="a">
      <?php echo $row['product_detail'];?>
        <!-- <li>Rechargeble battery option</li>
        -->
      </ul>
      <p class="pricing">₹ <?php echo $row['product_price'];?></p>
      <button type="button" class="btn btn-primary"data-toggle="modal" data-target="#myModal<?=$key?>">SHOP NOW</button>
      <div class="modal fade" id="myModal<?=$key?>" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>
            </div>
            <form method="post" action="cart.php?action=add&id=<?= base64_encode($row["id"]); ?>"> 
            <div class="modal-body">
              
              <div class="row">
                <div class="col-md-4 col-xs-12">
                  <img src="../upload_data/<?php echo $row['product_image'];?>" class="printercardimage" alt="../upload_data/<?php echo $row['product_image'];?>" style="width:182px" "height:30px" "margin-top:-5px">
                </div>
                <input type="hidden" name="product_img" class="form-control" value="<?=$row['product_image'];?>">
                <input type="hidden" name="quantity" class="form-control" value="1">
                <input type="hidden" name="hidden_name" value="<?php echo $row["product_name"]; ?>">
                <input type="hidden" name="hidden_price" value="<?php echo $row["product_price"]; ?>">
                <div class="col-md-8">
                  <center><h4><?php echo $row['product_name'];?></h4></center>
                  <br>
                  <ul class="a">
                     <?php echo $row['product_detail'];?>
                  </ul>
                </div>
              </div>
              <p> ₹ <?php echo $row['product_price'];?><br>
                </p>
            </div>
            <div class="modal-footer">
                 <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-primary"
                                       value="Add to Cart"> 
            </div>
            </form>
          </div>
          
        </div>
      </div>
    </div>
</div>
 <?php }?>
</div> 



    <!--shipping area start-->
<!--<section class="shipping_area mb-70">
        <div class="container">
            <div class=" row">
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping1.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>Free Shipping</h2>
                            <p>Free shipping on all US order</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping2.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>Support 24/7</h2>
                            <p>Contact us 24 hours a day</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping3.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>100% Money Back</h2>
                            <p>You have 30 days to Return</p>
                        </div>
                    </div>
                </div> 
                <div class="col-lg-3 col-md-6">
                    <div class="single_shipping">
                        <div class="shipping_icone">
                            <img src="assets/img/about/shipping4.png" alt="">
                        </div>
                        <div class="shipping_content">
                            <h2>Payment Secure</h2>
                            <p>We ensure secure payment</p>
                        </div>
                    </div>
                </div>                          
            </div>
        </div>
    </section>-->
    <!--shipping area end-->
    
    <!--banner area start-->
    <!--<div class="banner_area mb-40">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-lg-3 col-md-3">-->
    <!--                <div class="single_banner mb-30">-->
    <!--                    <div class="banner_thumb">-->
    <!--                        <a href="shop.html"><img src="assets/img/bg/banner_1.jpg" alt=""  class="img-responsive imagebanner"></a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-6 col-md-6">-->
    <!--                <div class="single_banner mb-30">-->
    <!--                    <div class="banner_thumb">-->
    <!--                        <a href="shop.html"><img src="assets/img/bg/banner_3.jpg" alt=""></a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-3 col-md-3">-->
    <!--                <div class="single_banner mb-30">-->
    <!--                    <div class="banner_thumb">-->
    <!--                        <a href="shop.html"><img src="assets/img/bg/banner_2.jpg" alt=""></a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--banner area end-->
    
    <!--product area start-->
    <!--<section class="product_area mb-46">-->
     
    <!--    <div class="container conproduct">-->
    <!--        <div class="row">-->
    <!--            <div class="col-12">-->
    <!--                <div class="section_title">-->
    <!--                    <h2>Hot Deals Products</h2>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div> -->
    <!--        <div class="product_carousel product_column5 owl-carousel">-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img1.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img2.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Natus erro at congue massa commodo sit</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img4.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Itaque earum velit elementum</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img5.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Mauris tincidunt eros posuere placerat</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img1.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Morbi ornare vestibulum massa</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/product9.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/product10.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Porro quisquam eget feugiat pretium</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img4.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Laudantium enim fringilla dignissim ipsum primis</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--            <article class="single_product">-->
    <!--                <figure>-->
    <!--                    <div class="product_thumb">-->
    <!--                        <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img4.jpg" alt=""></a>-->
    <!--                        <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img5.jpg" alt=""></a>-->
    <!--                        <div class="label_product">-->
    <!--                            <span class="label_sale">sale</span>-->
    <!--                        </div>-->
    <!--                        <div class="action_links">-->
    <!--                            <ul>-->
    <!--                                <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>-->
    <!--                                <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>-->
    <!--                                <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                        <div class="add_to_cart">-->
    <!--                            <a href="cart.html" title="add to cart">Add to cart</a>-->
    <!--                        </div>-->
    <!--                        <div class="product_timing">-->
    <!--                            <div data-countdown="2023/12/15"></div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <figcaption class="product_content">-->
    <!--                       <div class="price_box">-->
    <!--                            <span class="old_price">$86.00</span>  -->
    <!--                            <span class="current_price">$79.00</span>  -->
    <!--                        </div>-->
    <!--                        <h3 class="product_name"><a href="product-countdown.html">Natus erro at congue massa commodo sit</a></h3>-->
    <!--                    </figcaption>-->
    <!--                </figure>-->
    <!--            </article>-->
    <!--        </div>   -->
    <!--    </div>-->
    
    <!--</section>-->
    <!--product area end-->
    
    <!--banner area start-->
    <!--<div class="banner_area mb-40">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-lg-6 col-md-6">-->
    <!--                <div class="single_banner mb-30">-->
    <!--                    <div class="banner_thumb banner">-->
    <!--                        <a href="shop.html"><img src="assets/img/bg/b7.jpg " alt="" class="img-responsive imgb7"></a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-6 col-md-6">-->
    <!--                <div class="single_banner mb-30">-->
    <!--                    <div class="banner_thumb banner1">-->
    <!--                        <a href="shop.html"><img src="assets/img/bg/bn.jpg" alt="" class="img-responsive imgbn"></a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--banner area end-->
    
    <!--top- category area start-->
   <!-- <section class="top_category_product mb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-3">
                    <div class="top_category_header">
                        <h3>Top Categories This Week</h3>
                        <p>Aliquam eget consectetuer habitasse interdum.</p>
                        <a href="shop.html">Show All Categories</a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-9">
                    <div class="top_category_container category_column5 owl-carousel">
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.html"><img src="assets/img/s-product/category1.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.html">Games & Consoles </a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.html"><img src="assets/img/s-product/category2.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.html">Home Accessories</a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.html"><img src="assets/img/s-product/category3.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.html">TV & Audio</a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.html"><img src="assets/img/s-product/category4.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.html">Games & Consoles </a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.html"><img src="assets/img/s-product/category5.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.html">Laptop & Tablets </a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                        <div class="col-lg-2">
                            <article class="single_category">
                                <figure>
                                    <div class="category_thumb">
                                        <a href="shop.html"><img src="assets/img/s-product/category2.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="category_name">
                                        <h3><a href="shop.html">Home Accessories</a></h3>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--top- category area end-->
    
    <!--featured product area start-->
    <!--<section class="featured_product_area mb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                       <h2>Featured Products</h2>
                    </div>
                </div>
            </div>
            <div class="row featured_container featured_column3">
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product13.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product14.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">sale</span>
                                </div>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Pellentesque posuere hendrerit dui</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product16.jpg" alt=""></a>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="old_price">$86.00</span>  
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Auctor gravida enim pellentesque quam</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product17.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product18.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">sale</span>
                                </div>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="old_price">$86.00</span>  
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Kaoreet lobortis sagittis pellentesque</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product19.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product20.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">sale</span>
                                </div>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="old_price">$86.00</span>  
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Cras neque honcus consectetur magna</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product21.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product22.jpg" alt=""></a>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Duis pulvinar obortis eleifend elementum</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product23.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product24.jpg" alt=""></a>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="old_price">$86.00</span>  
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Fusce ultricies  dolor vitae tristique suscipit</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product15.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product16.jpg" alt=""></a>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="old_price">$86.00</span>  
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Natus erro at congue massa commodo sit</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.html"><img src="assets/img/product/product17.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product18.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">sale</span>
                                </div>
                            </div>
                            <figcaption class="product_content">
                               <div class="price_box">
                                    <span class="old_price">$86.00</span>  
                                    <span class="current_price">$79.00</span>  
                                </div>
                                <h3 class="product_name"><a href="product-details.html">Cras neque honcus consectetur magna</a></h3>
                                <div class="add_to_cart">
                                    <a href="cart.html" title="add to cart">Add to cart</a>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
            </div> 
        </div>
    </section>-->
    <!--featured product area end-->
    
    <!--product area start-->
    <!--<section class="product_area mb-46">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Computer & Laptop</h2>
                    </div>
                </div>
            </div> 
            <div class="product_carousel product_column5 owl-carousel">
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product1.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product2.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Natus erro at congue massa commodo sit</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product3.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Itaque earum velit elementum</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product5.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product6.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Mauris tincidunt eros posuere placerat</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product7.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product8.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Morbi ornare vestibulum massa</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product9.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product10.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Porro quisquam eget feugiat pretium</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product11.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product12.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Laudantium enim fringilla dignissim ipsum primis</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.html"><img src="assets/img/product/product4.jpg" alt=""></a>
                            <a class="secondary_img" href="product-details.html"><img src="assets/img/product/product5.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-details.html">Natus erro at congue massa commodo sit</a></h3>
                        </figcaption>
                    </figure>
                </article>
            </div>   
        </div>
    </section>-->
    <!--product area end-->

<div class="container-fluid cardcontainer">
<div class="row cardrow">
    <div class="col-md-4">
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <img src="assets/img/bg/printer1.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back">
     <h4 style="margin-top:60px">Eco Tank PhotoPrinter</h4>
      <p style="text-align: justify; margin-left:9px; margin-right:9px; padding-left:10px;
    padding-right:10px; padding-top: 10px";>Give life to all your creative ideas with the advanced features of Epson's range of EcoTank Photo Printers. Epson's UltraChrome pigment ink set and the revolutionary Micro Piezo printhead ensure ultra high-quality prints with incredible detail and vivid colours.</p> 
      
    </div>
  </div>
</div>
</div>

  <div class="col-md-4">
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
     <img src="assets/img/bg/printer2.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back">
     <h4 style="margin-top:60px" "padding:0px";>Eco Tank PhotoPrinter</h4> 
      <p style="text-align: justify; margin-left:9px; margin-right:9px; padding-left:10px;
    padding-right:10px; padding-top: 10px";>Give life to all your creative ideas with the advanced features of Epson's range of EcoTank Photo Printers. Epson's UltraChrome pigment ink set and the revolutionary Micro Piezo printhead ensure ultra high-quality prints with incredible detail and vivid colours.</p> 
      
    </div>
  </div>
</div>
</div>

  <div class="col-md-4">
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="assets/img/bg/printer3.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back">
      <h4 style="margin-top:60px"; >Eco Tank PhotoPrinter</h4> 
      <p style="text-align: justify; margin-left:9px; margin-right:9px; padding-left:10px;
    padding-right:10px; padding-top: 10px";>Give life to all your creative ideas with the advanced features of Epson's range of EcoTank Photo Printers. Epson's UltraChrome pigment ink set and the revolutionary Micro Piezo printhead ensure ultra high-quality prints with incredible detail and vivid colours.</p> 
      
    </div>
  </div>
</div>
</div>

</div>
</div>
 
                    <div class="testimonial_are">
                        <div class="section_title">
                            <h2>Testimonials</h2>
                        </div>
                        <div class="testimonial_active owl-carousel">       
                            <article class="single_testimonial">
                                <figure>
                                    <div class="testimonial_thumb">
                                        <a href="#"><img src="assets/img/about/testimonial1.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="testimonial_content">
                                        <p>Epson, is a Japanese electronics company and one of the world's largest manufacturers of computer printers, and information and imaging related equipment.!</p>
                                        <h3><a href="#">Kathy Young</a><span> - CEO of D2sepson</span></h3>
                                    </figcaption>
                                    
                                </figure>
                            </article> 
                            <article class="single_testimonial">
                                <figure>
                                    <div class="testimonial_thumb">
                                        <a href="#"><img src="assets/img/about/testimonial2.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="testimonial_content">
                                        <p>Perfect Themes and the best of all that you have many options to choose! Best Support team ever! Thank you very much!</p>
                                        <h3><a href="#">John Sullivan</a><span> - Customer</span></h3>
                                    </figcaption>
                                    
                                </figure>
                            </article> 
                            <article class="single_testimonial">
                                <figure>
                                    <div class="testimonial_thumb">
                                        <a href="#"><img src="assets/img/about/testimonial3.jpg" alt=""></a>
                                    </div>
                                    <figcaption class="testimonial_content">
                                        <p>Code, template and others are very good. The support has served me immediately and solved my problems when I need help. Are to be congratulated.</p>
                                        <h3><a href="#">Jenifer Brown</a><span> - Manager of AZ</span></h3>
                                    </figcaption>
                                    
                                </figure>
                            </article>      
                        </div>   
                    </div>
                     <!--testimonials section end-->
                </div>
            </div> 
        </div>
    </section>
    
    <?php
include_once("footer.php");
    ?>
   
    <!-- modal area start-->
    <div class="modal fade" id="modal_box" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <div class="modal_tab">  
                                    <div class="tab-content product-details-large">
                                        <div class="tab-pane fade show active" id="tab1" role="tabpanel" >
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product1.jpg" alt=""></a>    
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab2" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product2.jpg" alt=""></a>    
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab3" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product3.jpg" alt=""></a>    
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab4" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product5.jpg" alt=""></a>    
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal_tab_button">    
                                        <ul class="nav product_navactive owl-carousel" role="tablist">
                                            <li >
                                                <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab" aria-controls="tab1" aria-selected="false"><img src="assets/img/product/product1.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                 <a class="nav-link" data-toggle="tab" href="#tab2" role="tab" aria-controls="tab2" aria-selected="false"><img src="assets/img/product/product2.jpg" alt=""></a>
                                            </li>
                                            <li>
                                               <a class="nav-link button_three" data-toggle="tab" href="#tab3" role="tab" aria-controls="tab3" aria-selected="false"><img src="assets/img/product/product3.jpg" alt=""></a>
                                            </li>
                                            <li>
                                               <a class="nav-link" data-toggle="tab" href="#tab4" role="tab" aria-controls="tab4" aria-selected="false"><img src="assets/img/product/product5.jpg" alt=""></a>
                                            </li>

                                        </ul>
                                    </div>    
                                </div>  
                            </div> 
                            <div class="col-lg-7 col-md-7 col-sm-12">
                                <div class="modal_right">
                                    <div class="modal_title mb-10">
                                        <h2>Handbag feugiat</h2> 
                                    </div>
                                    <div class="modal_price mb-10">
                                        <span class="new_price">$64.99</span>    
                                        <span class="old_price" >$78.99</span>    
                                    </div>
                                    <div class="modal_description mb-15">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam in quos qui nemo ipsum numquam, reiciendis maiores quidem aperiam, rerum vel recusandae </p>    
                                    </div> 
                                    <div class="variants_selects">
                                        <div class="variants_size">
                                           <h2>size</h2>
                                           <select class="select_option">
                                               <option selected value="1">s</option>
                                               <option value="1">m</option>
                                               <option value="1">l</option>
                                               <option value="1">xl</option>
                                               <option value="1">xxl</option>
                                           </select>
                                        </div>
                                        <div class="variants_color">
                                           <h2>color</h2>
                                           <select class="select_option">
                                               <option selected value="1">purple</option>
                                               <option value="1">violet</option>
                                               <option value="1">black</option>
                                               <option value="1">pink</option>
                                               <option value="1">orange</option>
                                           </select>
                                        </div>
                                        <div class="modal_add_to_cart">
                                            <form action="#">
                                                <input min="0" max="100" step="2" value="1" type="number">
                                                <button type="submit">add to cart</button>
                                            </form>
                                        </div>   
                                    </div>
                                    <div class="modal_social">
                                        <h2>Share this product</h2>
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>    
                                    </div>      
                                </div>    
                            </div>    
                        </div>     
                    </div>
                </div>    
            </div>
        </div>
    </div>
    <!-- modal area end-->
<!-- JS
============================================ -->

<script>
/* user defined variables */
var timeOnSlide = 3, 		
    // the time each image will remain static on the screen, measured in seconds
timeBetweenSlides = 1, 	
    // the time taken to transition between images, measured in seconds

// test if the browser supports animation, and if it needs a vendor prefix to do so
    animationstring = 'animation',
    animation = false,
    keyframeprefix = '',
    domPrefixes = 'Webkit Moz O Khtml'.split(' '), 
    // array of possible vendor prefixes
    pfx  = '',
    slidy = document.getElementById("slidy"); 
if (slidy.style.animationName !== undefined) { animation = true; } 
// browser supports keyframe animation w/o prefixes

if( animation === false ) {
  for( var i = 0; i < domPrefixes.length; i++ ) {
    if( slidy.style[ domPrefixes[i] + 'AnimationName' ] !== undefined ) {
      pfx = domPrefixes[ i ];
      animationstring = pfx + 'Animation';
      keyframeprefix = '-' + pfx.toLowerCase() + '-';
      animation = true;
      break;
    }
  }
}

if( animation === false ) {
  // animate in JavaScript fallback
} else {
  var images = slidy.getElementsByTagName("img"),
      firstImg = images[0], 
      // get the first image inside the "slidy" element.
      imgWrap = firstImg.cloneNode(false);  // copy it.
  slidy.appendChild(imgWrap); // add the clone to the end of the images
  var imgCount = images.length, // count the number of images in the slide, including the new cloned element
      totalTime = (timeOnSlide + timeBetweenSlides) * (imgCount - 1), // calculate the total length of the animation by multiplying the number of _actual_ images by the amount of time for both static display of each image and motion between them
      slideRatio = (timeOnSlide / totalTime)*100, // determine the percentage of time an induvidual image is held static during the animation
      moveRatio = (timeBetweenSlides / totalTime)*100, // determine the percentage of time for an individual movement
      basePercentage = 100/imgCount, // work out how wide each image should be in the slidy, as a percentage.
      position = 0, // set the initial position of the slidy element
      css = document.createElement("style"); // start marking a new style sheet
  css.type = "text/css";
  css.innerHTML += "#slidy { text-align: left; margin: 0; font-size: 0; position: relative; width: " + (imgCount * 100) + "%;  }\n"; // set the width for the slidy container
  css.innerHTML += "#slidy img { float: left; width: " + basePercentage + "%; }\n";
  css.innerHTML += "@"+keyframeprefix+"keyframes slidy {\n"; 
  for (i=0;i<(imgCount-1); i++) { // 
    position+= slideRatio; // make the keyframe the position of the image
    css.innerHTML += position+"% { left: -"+(i * 100)+"%; }\n";
    position += moveRatio; // make the postion for the _next_ slide
    css.innerHTML += position+"% { left: -"+((i+1) * 100)+"%; }\n";
}
  css.innerHTML += "}\n";
  css.innerHTML += "#slidy { left: 0%; "+keyframeprefix+"transform: translate3d(0,0,0); "+keyframeprefix+"animation: "+totalTime+"s slidy infinite; }\n"; // call on the completed keyframe animation sequence
document.body.appendChild(css); // add the new stylesheet to the end of the document
}

</script>

</body>
</html>