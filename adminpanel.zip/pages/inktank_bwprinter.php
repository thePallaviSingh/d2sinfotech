<?php
include_once("header.php");
?>
<div class="text-anim">
  <div id="container-anim">
    <div id="flip">
      <div>
        <div>printers</div>
      </div>
    </div>
  </div>
</div>
<div class="row colrow">
<div class="col-md-4 colrow1">
<div class="card">	
<center><img src="assets/img/bg/bw1.jpg" class="printercardimage"></center>
<h4>Eco Tank M205</h4>
<ul class="a">
  <li>Print resolution of 1440 dpi</li>
  <li>High print speed of 34 ppm*</li>
  <li>USB 2.0 and WiFi connectivity</li>
  <li>30-page Automatic Document Feeder</li>
</ul>
<p class="pricing">Rs. 14,599 *</p>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>


 <!--  Modal -->
  <!-- <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>This is a small modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div> -->

    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank M205 added to your shopping cart.</h4>

        </div>
          <div class="modal-body">
          <div class="row">
        <div class="col-md-4">
        <img src="assets/img/bg/bw1.jpg" class="printercardimage" style="width:182px" "height:30px" "margin-top:-5px">
        </div>
        <div class="col-md-8">
         <center><h4>EcoTank M205</h4></center>
EcoTank M205 Multifunction InkTank Printer<br>
<ul class="a">
  <li>Print resolution of 1440 dpi</li>
  <li>High print speed of 34 pp...
</li>
  
</ul>
          </div>
        </div>
       <p> Rs. 18,299 *<br>
     price inclusive of all taxes</br>
Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 
</div>
</div>
<div class="col-md-4 colrow1">
<div class="card">		
<center><img src="assets/img/bg/bw3.jpg" class="printercardimage"></center>
<h4>Eco Tank M200</h4>
<ul class="a">
  <li>Print resolution of 1440 dpi</li>
  <li>High print speed of 34 ppm*</li>
  <li>USB 2.0 and Ethernet</li>
  <li>30-page Automatic Document Feeder</li>
</ul>
<p class="pricing">Rs. 3,999 *</p>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank M200 added to your shopping cart.</h4>
        </div>
        <!-- <div class=" col-md-4">
      <img src="assets/img/bg/p2.jpg" class="printercardimage1">
     </div> -->
        <div class="modal-body">
          <div class="col-md-4">
  <img src="assets/img/bg/bw3.jpg"  alt="img1.
  " class="printercardimage">
 </div>
 <div class="col-md-8">
        <p> Rs. 13,999 *<br>
price inclusive of all taxes<br>
Free shipping on order above Rs.599</p>
        </div>
      </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 
 
</div>
</div>
<div class="col-md-4 colrow1">
<div class="card">		
	<center><img src="assets/img/bg/bw5.jpg" class="printercardimage"></center>
    <h4>Eco Tank M105</h4>
<ul class="a">
  <li>High print speed of 34 ppm*</li>
  <li>USB 2.0 and WiFi connectivity</li>
  <li>12 paise per B&W A4 print</li>
  <li>Print resolution of 1440 dpi</li>
</ul>
<p class="pricing">Rs. 9,999 *</p>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank M105 added to your shopping cart.</h4>

        </div>
        <div class="modal-body">
        <p> Rs. 9,999 *<br>
price inclusive of all taxes<br>
Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 
 
</div>

</div>
</div>

<div class="row colrow">
<div class="col-md-4 colrow1">
<div class="card">  
<center><img src="assets/img/bg/bw6.jpg" class="printercardimage"></center>
<h4>Eco Tank M105</h4>
<ul class="a">
  <li>High print speed of 34 ppm*</li>
  <li>High print speed of 34 ppm*</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 9,999 *</p>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank M105 added to your shopping cart.</h4>

        </div>
        <div class="modal-body">
        <p> Rs. 9,999 *<br>
price inclusive of all taxes</br>
Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 

</div>
</div>
<div class="col-md-4 colrow1">
<div class="card">    
<center><img src="assets/img/bg/bw7.jpg" class="printercardimage"></center>
<h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button> 
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>

        </div>
        <div class="modal-body">
        <p> Rs. 29,099 *<br>
price inclusive of all taxes<br>
Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 

</div>
</div>
<div class="col-md-4 colrow1">
<div class="card">    
 <center> <img src="assets/img/bg/bw8.jpg" class="printercardimage"></center>
    <h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>

        </div>
        <div class="modal-body">
        <p> Rs. 29,099 *<br>
price inclusive of all taxes<br>
Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 

</div>

</div>


<div class="col-md-4 colrow1">
<div class="card">	
<center><img src="assets/img/bg/bw1.jpg" class="printercardimage"></center>
<h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>


 <!--  Modal -->
  <!-- <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>This is a small modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div> -->

    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>

        </div>
          <div class="modal-body">
          <div class="row">
        <div class="col-md-4">
        <img src="assets/img/bg/bw2.jpg" class="printercardimage" style="width:182px" "height:30px" "margin-top:-5px">
        </div>
        <div class="col-md-8">
         <center><h4>EcoTank L805</h4></center>
EcoTank L3116 Multifunction InkTank Printer<br>
<ul class="a">
  <li>Print, scan and copy functions</li>
  <li>Borderless Printing...</li>
  
</ul>
          </div>
        </div>
       <p> Rs. 18,299 *<br>
      price inclusive of all taxes<br>
      Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 
</div>
</div>

<div class="col-md-4 colrow1">
<div class="card">	
<center><img src="assets/img/bg/bw1.jpg" class="printercardimage"></center>
<h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>


 <!--  Modal -->
  <!-- <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>This is a small modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div> -->

    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>

        </div>
          <div class="modal-body">
          <div class="row">
        <div class="col-md-4">
        <img src="assets/img/bg/bw10.jpg" class="printercardimage" style="width:182px" "height:30px" "margin-top:-5px">
        </div>
        <div class="col-md-8">
         <center><h4>EcoTank L805</h4></center>
EcoTank L3116 Multifunction InkTank Printer<br>
<ul class="a">
  <li>Print, scan and copy functions</li>
  <li>Borderless Printing...</li>
  
</ul>
          </div>
        </div>
       <p> Rs. 18,299 *<br>
      price inclusive of all taxes<br>
      Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 
</div>
</div>


<div class="col-md-4 colrow1">
<div class="card">	
<center><img src="assets/img/bg/bw11.jpg" class="printercardimage"></center>
<h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">SHOP NOW</button>


 <!--  Modal -->
  <!-- <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>This is a small modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div> -->

    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>

        </div>
          <div class="modal-body">
          <div class="row">
        <div class="col-md-4">
        <img src="assets/img/bg/bw12.jpg" class="printercardimage" style="width:182px" "height:30px" "margin-top:-5px">
        </div>
        <div class="col-md-8">
         <center><h4>EcoTank L805</h4></center>
    EcoTank L3116 Multifunction InkTank Printer<br>
    <ul class="a">
    <li>Print, scan and copy functions</li>
    <li>Borderless Printing...</li>
    </ul>
          </div>
        </div>
       <p> Rs. 18,299 *<br>
      price inclusive of all taxes<br>
      Free shipping on order above Rs.599</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Go to Cart</button>
        </div>
      </div>
      
    </div>
  </div> 
</div>
</div>



</div>



<?php

include_once("footer.php");
?>