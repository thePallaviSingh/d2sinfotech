 <?php session_start(); ?>
<?php print_r($_SESSION['customer'])?>