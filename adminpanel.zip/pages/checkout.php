<?php
include_once("header.php");
?>
  <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Checkout</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
    <!--breadcrumbs area end-->
 <!--Checkout page section-->
    <div class="Checkout_section mt-60">
       <div class="container">
            <div class="row">
               <div class="col-12">
                    <div class="user-actions">
                        <?php if(!isset($_SESSION['customer'])): ?>
                        <h3> 
                            <i class="fa fa-file-o" aria-hidden="true"></i>
                            Returning customer?
                            <a class="Returning" href="login.php" aria-expanded="true">Click here to login</a>     

                        </h3>
                        <?php else: ?>
                         <div id="checkout_login" class="collapse" data-parent="#accordion">
                            <div class="checkout_info">
                                <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new customer please proceed to the Billing & Shipping section.</p>  
                                <form action="#">  
                                    <div class="form_group">
                                        <label>Username or email <span>*</span></label>
                                        <input type="text">     
                                    </div>
                                    <div class="form_group">
                                        <label>Password  <span>*</span></label>
                                        <input type="text">     
                                    </div> 
                                    <div class="form_group group_3 ">
                                        <button type="submit">Login</button>
                                        <label for="remember_box">
                                            <input id="remember_box" type="checkbox">
                                            <span> Remember me </span>
                                        </label>     
                                    </div>
                                    <a href="#">Lost your password?</a>
                                </form>          
                            </div>
                        </div>  

                    </div>
                    <div class="user-actions">
                        <h3> 
                            <i class="fa fa-file-o" aria-hidden="true"></i>
                            Returning customer?
                            <a class="Returning" href="#" data-toggle="collapse" data-target="#checkout_coupon" aria-expanded="true">Click here to enter your code</a>     

                        </h3>
                         <div id="checkout_coupon" class="collapse" data-parent="#accordion">
                            <div class="checkout_info">
                                <form action="#">
                                    <input placeholder="Coupon code" type="text">
                                    <button type="submit">Apply coupon</button>
                                </form>
                            </div>
                        </div>    
                    </div>    
               </div>
            </div>
            <div class="checkout_form">
                 <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <form action="" method="POST">
                        <div class="table_desc">
                            <div class="cart_page table-responsive">
                                <table>
                            <thead>
                                <tr>
                                    <th class="product_thumb">Image</th>
                                    <th class="product_name">Product</th>
                                    <th class="product-price">Price</th>
                                    <th class="product_quantity">Quantity</th>
                                    <th class="product_total">Total</th>
                                </tr>
                            </thead>
                            <tbody>  
                                <?php  if(!empty($_SESSION["cart"])){
                                    $total = 0;
                                    foreach ($_SESSION["cart"] as $key => $value) {
                                        ?>
                                <tr>
                                    <td class="product_thumb"><a href="#"><img src="../upload_data/<?=$value["product_img"]; ?>" alt=""></a></td>
                                    <td class="product_name"><a href="#"><?php echo $value["item_name"]; ?></a></td>
                                    <td class="product-price"><?php echo $value["product_price"]; ?></td>
                                    <td class="product_quantity"> <?php echo $value["item_quantity"]; ?></td>
                                    <td class="product_total"><?php echo number_format($value["item_quantity"] * $value["product_price"], 2); ?></td>


                                </tr>
                                <?php
                                 $total = $total + ($value["item_quantity"] * $value["product_price"]);
                                }
                                 ?>
                                 <?php
                    }
                ?>
                            </tbody>
                        </table>   
                            </div>       
                        </div>
                      </form>
                    </div>
                </div>
                <div class="row">
                   <!--  <div class="col-lg-6 col-md-6">
                    </div> -->
                    <div class="col-lg-12 col-md-12">
                          <div class="coupon_code right">
                                <h3>Cart Totals</h3>
                                <div class="coupon_inner">
                                   <div class="cart_subtotal">
                                       <p>Subtotal</p>
                                       <p class="cart_amount"><?=$total?></p>
                                   </div> 
                                   <div class="cart_subtotal">
                                       <p>Total</p>
                                       <p class="cart_amount"><?=$total?></p>
                                   </div> 
                                </div>
                            </div>
                    </div>
                </div>
<?php 
 $query="select * from tbl_customer where cust_token='".$_SESSION['customer']['cust_token']."'";
                $q=mysqli_query($con,$query) or die(mysqli_error($con));
                foreach($q as $row) {
                      $cust_b_name = $row['cust_b_name'];
                      $cust_b_phone = $row['cust_b_phone'];
                      $cust_b_country = $row['cust_b_country']; 
                      $cust_b_address = $row['cust_b_address'];
                      $cust_b_city = $row['cust_b_city'];
                      $cust_b_state = $row['cust_b_state'];
                      $cust_b_zip = $row['cust_b_zip'];
                      $cust_b_name = $row['cust_b_name'];

                      $cust_s_name = $row['cust_s_name'];
                      $cust_s_phone = $row['cust_s_phone'];
                      $cust_s_country = $row['cust_s_country']; 
                      $cust_s_address = $row['cust_s_address'];
                      $cust_s_city = $row['cust_s_city'];
                      $cust_s_state = $row['cust_s_state'];
                      $cust_s_zip = $row['cust_s_zip'];
                      $cust_s_name = $row['cust_s_name'];
                } 
?>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                       <form action="#">
                        <h3>Billing Details</h3>
                            <div class="row">
                            <table class="table table-bordered">
                                <tbody>
                                <tr>
                                    <td>Full Name</td>
                                    <td><?=$cust_b_name?><p></p></td>
                                </tr> 
                                <tr>
                                    <td>Phone Number</td>
                                    <td><?=$cust_b_phone?>></td>
                                </tr>
                                <tr>
                                    <td>Country</td>
                                    <td>
                                    <?=$cust_b_country ?></td>
                                </tr>
                                <tr>
                                    <td>Address</td>
                                    <td>
                                    <?php echo nl2br($cust_b_address); ?></td>
                                </tr>
                                <tr>
                                    <td>City</td>
                                    <td><?=$cust_b_city?></td>
                                </tr>
                                <tr>
                                    <td>State</td>
                                    <td><?=$cust_b_state ?></td>
                                </tr>
                                <tr>
                                    <td>Zip Code</td>
                                    <td><?=$cust_b_zip?></td>
                                </tr>
                            </tbody>
                            </table>
                             </div>
                        </form>   
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <form action="#">
                        <h3>Shipping Address</h3>
                            <div class="row">
                            <table class="table table-bordered">
                                <tbody>
                                <tr>
                                    <td>Full Name</td>
                                    <td><?=$cust_s_name ?><p></p></td>
                                </tr> 
                                <tr>
                                    <td>Phone Number</td>
                                    <td><?=$cust_s_phone?></td>
                                </tr>
                                <tr>
                                    <td>Country</td>
                                    <td>
                                   <?=$cust_s_country?></td>
                                </tr>
                                <tr>
                                    <td>Address</td>
                                    <td>
                                    <?=$cust_s_address ?></td>
                                </tr>
                                <tr>
                                    <td>City</td>
                                    <td><?=$cust_s_city?></td>
                                </tr>
                                <tr>
                                    <td>State</td>
                                    <td><?=$cust_s_state ?></td>
                                </tr>
                                <tr>
                                    <td>Zip Code</td>
                                    <td><?=$cust_s_zip?></td>
                                </tr>
                            </tbody>
                            </table>
                             </div>
                        </form>     
                    </div>
                </div> 

                <div class="row">
                        <?php
                        $checkout_access = 1;  
               
                        if(
                            ($cust_b_name=='') || 
                            ($cust_b_phone=='') ||
                            ($cust_b_country=='') ||
                            ($cust_b_address=='') ||
                            ($cust_b_city=='') ||
                            ($cust_b_state=='') ||
                            ($cust_b_zip=='') ||
                            ($cust_s_name=='') || 
                            ($cust_s_phone=='') ||
                            ($cust_s_country=='') ||
                            ($cust_s_address=='') ||
                            ($cust_s_city=='') ||
                            ($cust_s_state=='') ||
                            ($cust_s_zip=='')
                        ) {
                            $checkout_access = 0;
                        }
                        ?>
                        <?php if($checkout_access == 0): ?>
                                <div style="color:red;font-size:22px;margin-bottom:50px;">
                                    You must have to fill up all the billing and shipping information from your dashboard panel in order to checkout the order. Please fill up the information going to <a href="myaccount.php" style="color:red;text-decoration:underline;">this link</a>.
                                </div>
                            </div>
                        <?php else: ?>
                    <div class="col-lg-6 col-md-6">
                          <div class="col-md-12 form-group">
                            <form action="../backend/init.php" method="post" id="bank_form">
                                    <input type="hidden" name="amount" value="<?php echo $total; ?>">
                                        <label for="">Select Payment Method</label>
                                        <select name="" class="form-control">
                                            <option value="">Select a Method</option>
                                            <option value="cod">Cash On delivery</option> 
                                        </select>

                                        <button type="submit" class="btn btn-primary">Pay Now</button>
                            </form>
                            </div> 
                    </div>
                      <?php endif; ?>
                </div>

            </div>
              <?php endif; ?>  
        </div>       
    </div>
    <!--Checkout page section end-->

<?php
include_once("footer.php");
?>