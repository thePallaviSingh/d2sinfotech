<?php
include_once("header.php");
?>
<link rel="stylesheet" href="photo_printer.css">
<div class="container-fluid conbanner">
	<img src="assets/img/bg/inkbanner.jpg" class="bannerimage">
</div>
 <!--product area start-->
    <!-- <section class="product_area mb-46">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>Hot Deals Products</h2>
                    </div>
                </div>
            </div> 
            <div class="product_carousel product_column5 owl-carousel">
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img1.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img2.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Natus erro at congue massa commodo sit</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img4.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Itaque earum velit elementum</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img5.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Mauris tincidunt eros posuere placerat</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img1.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Morbi ornare vestibulum massa</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/product9.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/product10.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Porro quisquam eget feugiat pretium</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img4.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img3.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Laudantium enim fringilla dignissim ipsum primis</a></h3>
                        </figcaption>
                    </figure>
                </article>
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-countdown.html"><img src="assets/img/product/img4.jpg" alt=""></a>
                            <a class="secondary_img" href="product-countdown.html"><img src="assets/img/product/img5.jpg" alt=""></a>
                            <div class="label_product">
                                <span class="label_sale">sale</span>
                            </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist"><a href="wishlist.html" title="Add to Wishlist"><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
                                    <li class="compare"><a href="#" title="compare"><span class="ion-levels"></span></a></li>
                                    <li class="quick_button"><a href="#" data-toggle="modal" data-target="#modal_box"  title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                                </ul>
                            </div>
                            <div class="add_to_cart">
                                <a href="cart.html" title="add to cart">Add to cart</a>
                            </div>
                            <div class="product_timing">
                                <div data-countdown="2023/12/15"></div>
                            </div>
                        </div>
                        <figcaption class="product_content">
                           <div class="price_box">
                                <span class="old_price">$86.00</span>  
                                <span class="current_price">$79.00</span>  
                            </div>
                            <h3 class="product_name"><a href="product-countdown.html">Natus erro at congue massa commodo sit</a></h3>
                        </figcaption>
                    </figure>
                </article>
            </div>   
        </div>
    </section> -->
    <!--product area end-->
<div class="row colrow">
<div class="col-md-4 colrow1">
<div class="card">	
<img src="assets/img/product/ink1.jpg" class="printercardimage">
<h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
<button type="button" class="btn btn-primary">SHOP NOW</button>
</div>
</div>
<div class="col-md-4 colrow1">
<div class="card">		
<img src="assets/img/product/img3.jpg" class="printercardimage">
<h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
<button type="button" class="btn btn-primary">SHOP NOW</button>	
</div>
</div>
<div class="col-md-4 colrow1">
<div class="card">		
	<img src="assets/img/product/img2.jpg" class="printercardimage">
    <h4>Eco Tank LT805</h4>
<ul class="a">
  <li>Print speed up to 36 secs</li>
  <li>Rechargeble battery option</li>
  <li>Print resolution up to 5760dpi</li>
  <li>Lightweight and portable</li>
</ul>
<p class="pricing">Rs. 14,299 *</p>
<button type="button" class="btn btn-primary">SHOP NOW</button>
</div>

</div>
</div>
  <?php
include_once("footer.php")
    ?>
