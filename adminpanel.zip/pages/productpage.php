<?php
include_once("header.php");
include_once("connection.php");
?>
<div class="text-anim">
  <div id="container-anim">
    <div id="flip">
      <div>
        <div> Printers</div>
      </div>
    </div>
  </div>
</div>
<div class="row colrow">
  <!-- product -->
  <?php
  $id = base64_decode($_GET['tokenkey']);
  $sql="SELECT p.id,p.product_name,p.product_detail,p.product_price,p.product_image,s.product_subcategory,c.product_category FROM product_name p JOIN product_category c ON c.category_id=p.category_id   JOIN product_subcategory s ON s.subcategory_id=p.subcategory_id WHERE p.subcategory_id ='".$id."'";
  $result= mysqli_query($con,$sql);
  while($row=mysqli_fetch_array($result)) {
  $key =rand(100,999);
  ?>
  <div class="col-md-4 col-xs-12">
    <div class="card">
      
      <center><img src="../upload_data/<?php echo $row['product_image'];?>" class="printercardimage" alt="../upload_data/<?php echo $row['product_image'];?>"></center>
      <h4><?php echo $row['product_name'];?></h4>
      <ul class="a">
        <?=substr ($row['product_detail'], 0, 100);?>
        <!-- <li>Rechargeble battery option</li>
        -->
      </ul>
      <p class="pricing">₹ <?php echo $row['product_price'];?></p>
      <button type="button" class="btn btn-primary"data-toggle="modal" data-target="#myModal<?=$key?>">SHOP NOW</button>
      <div class="modal fade" id="myModal<?=$key?>" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">EcoTank L850 added to your shopping cart.</h4>
            </div>
            <form method="post" action="cart.php?action=add&id=<?= base64_encode($row["id"]); ?>">
              <div class="modal-body">
                
                <div class="row">
                  <div class="col-md-4 col-xs-4">
                    <img src="../upload_data/<?php echo $row['product_image'];?>" class="printercardimage" alt="../upload_data/<?php echo $row['product_image'];?>" style="width:182px" "height:30px" "margin-top:-5px">
                  </div>
                  <input type="hidden" name="product_img" class="form-control" value="<?=$row['product_image'];?>">
                  <input type="hidden" name="quantity" class="form-control" value="1">
                  <input type="hidden" name="hidden_name" value="<?php echo $row["product_name"]; ?>">
                  <input type="hidden" name="hidden_price" value="<?php echo $row["product_price"]; ?>">
                  <div class="col-md-8">
                    <center><h4><?php echo $row['product_name'];?></h4></center>
                    <br>
                    <ul class="a">
                      <?=substr ($row['product_detail'], 0, 100);?>
                    </ul>
                  </div>
                </div>
                <p> <?php echo $row['product_price'];?><br>
                </p>
              </div>
              <div class="modal-footer">
                <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-primary"
                value="Add to Cart">
              </div>
            </form>
          </div>
          
        </div>
      </div>
    </div>
  </div>
  <?php }?>
  <!--product -->
</div>
<?php
include_once("footer.php");
?>