<?php
include_once("header.php");
include_once("connection.php");
$otp=$_GET['otp'];
$usertoken=$_GET['tokenkey'];
$sql="SELECT id,usertoken,otp, status FROM tbl_reset ";
$query=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($query); 
    $row_token = $row['usertoken'];
     $cust_otp = $row['otp']; 
      if(isset($_POST['passwordreset'])) { 
           if($cust_otp != $otp){
               echo "<script>alert('Otp Not Match !')</script>";
           }elseif($row_token!=$usertoken){
                echo "<script>alert('Tokenkey not Match !')</script>";
           }elseif($_POST['newpwd'] != $_POST['conformpwd']){
                echo "<script>alert('New Password & Confirm Password not Match !')</script>";
           }else{
               $updatepass = "UPDATE tbl_customer SET cust_password='".$_POST['conformpwd']."' WHERE cust_token='".$usertoken."'";
                $query=mysqli_query($con,$updatepass);
           if($query == 1){
                echo "<script>alert('Password Updated !')</script>";
           }
           }
    }
 
?>
 <!--breadcrumbs area end--> 
    <!-- customer login start -->
    <div class="customer_login mt-60">
        <div class="container">
            <div class="row">
               <!--login area start-->
                <div class="col-lg-12 col-md-12">
                    <div class="account_form">
                        <h2>Reset Password</h2>
                       <form action="" method="POST">
                            <p>   
                               
                                 <label>New Password <span>*</span></label>
                                <input type="text" name="newpwd">
                                 <label>Conform Password <span>*</span></label>
                                <input type="text" name="conformpwd">
                             </p>   
                            <div class="login_submit">  
                               <!--<a href="reg.php">If not register then register?</a> -->
                                <button type="submit" name="passwordreset">Submit</button>
                                
                            </div>

                        </form>

                     </div>    
                </div>
                <!--login area start-->

                
            </div>
        </div>    
    </div>
     
    <!-- customer login end -->
<?php
include_once("footer.php");
?>
