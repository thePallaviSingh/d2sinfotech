<?php
include_once("header.php");
?>
<!--<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>-->
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script>
    function checkstatus(name,email,contact,message) {
               text=/^[a-z A-Z]+$/.test(name);
               if (text==false) {
                   alert('Enter valid name..!!');
                   return false;
               }
               
              var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(email) == false) 
        {
           
                alert('Invalid Email Address');
                return (false);
            }
            
            
      
   var phoneno = /^\d{10}$/;
  if(mobile.value.match(phoneno))
  {
      return true;
  }
  else
  {
     alert("Invalid Phone Number");
     return false;
  }
  
  text=/^[a-z A-Z]+$/.test(message);
               if (text==false) {
                   alert('Enter valid message..!!');
                   return false;
               }
    }
</script>
<?php
if(isset($_POST['submit']))
 {

     $Name=$_POST['name'];
	 $Email=$_POST['email'];
	 $contact=$_POST['mobile'];
	 $Message=$_POST['message'];
	 $to="sikriwal319@gmail.com";
	 $contact=$contact;
	 $message = "<h3>Hello Admin,<br>Here is the detail of d2s infotech epson service center  Form:<br>";
     $message.="Name : ".$Name."<br>";
     $message.="Email :".$Email."<br>";
     $message.="contact :". $contact."<br>";
     $message.="Message :". $Message.'</h3>';
	 $header = "MIME-Version: 1.0" . "\r\n";
     $header.= "Content-type:text/html;charset=UTF-8" . "\r\n";
	 $header.= 'From:'.$Email . "\r\n" ;
	
     $retval = mail ($to,$contact,$message,$header);
     if( $retval)
      {
      ?>
      <script>
      alert("message send successfully!!!");
      </script>
      <?php
      }
      }
      ?>
<!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
    <!--breadcrumbs area end-->
 <!--contact map start-->
    <div class="contact_map mt-60">
       <div class="map-area">
          <div id="googleMap">
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d112166.9520480485!2d77.255714!3d28.533189!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce3df9e600c5d%3A0x59f01c8ac3c0ce9!2sNew%20Delhi%2C%20Delhi%20110019%2C%20India!5e0!3m2!1sen!2sus!4v1583572173182!5m2!1sen!2sus" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" ></iframe>    
         
          </div>
       </div>
    </div>
    <!--contact map end-->
    <!--contact area start-->
    <div class="contact_area">
        <div class="container">   
            <div class="row">
                <div class="col-lg-6 col-md-12">
                   <div class="contact_message content">
                        <h3>contact us</h3>    
                         <p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram anteposuerit litterarum formas human. qui sequitur mutationem consuetudium lectorum. Mirum est notare quam</p>
                        <ul>
                            <li><i class="fa fa-fax"></i>  Address :304 3rd floor Saraswati house building no 27 nehru place new delhi-110019</li>
                            <li><i class="fa fa-phone"></i> <a href="#">edel74@epsonindia.in</a></li>
                            <li><i class="fa fa-envelope-o"></i> 0(1234) 567 890</li>
                        </ul>             
                    </div> 
                </div>
                <div class="col-lg-6 col-md-12">
                   <div class="contact_message form">
                        <h3>Tell us your project</h3>   
                        <form id='frm1' method="POST"  action=""  onsubmit='return checkstatus(name.value,email.value,mobile.value,message.value)'>
                            <p>  
                               <label> Your Name (required)</label>
                                <input name="name" placeholder="Name *" type="text"> 
                            </p>
                            <p>       
                               <label>  Your Email (required)</label>
                                <input name="email" placeholder="Email *" type="email">
                            </p>
                            <p>          
                               <label> Your Mobile (required)</label>
                               
                                <input name="mobile" id="mobile" placeholder="Mobile *" type="text">
                            </p>    
                            <div class="contact_textarea">
                                <label>  Your Message</label>
                                <textarea placeholder="Message *" name="message"  class="form-control2" ></textarea>     
                            </div>   
                            <button type="submit" name="submit"> Send</button>  
                            <p class="form-messege"></p>
                        </form> 
                    </div> 
                </div>
            </div>
        </div>    
    </div>
    <!--contact area end-->
<?php
include_once("footer.php");
?>