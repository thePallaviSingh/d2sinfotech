<?php
$host= "localhost";
$username= "epson_infotech";
$password= "epson_infotech";
$db= "epson_infotech";
$con= mysqli_connect($host,$username,$password,$db);
define ('SITE_ROOT',$_SERVER['DOCUMENT_ROOT'].'/demo/d2epson2/');

define ('img_ROOT','https://loopintechies.com/'.'/demo/d2epson2/');
?>
