<?php 
include_once("connection.php");
extract($_POST);
$id=$con->real_escape_string($id);
$status=$con->real_escape_string($status);
$sql=$con->query("UPDATE product_name SET status='$status' WHERE id='$id'");
echo 1;
?>
