   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
  include_once("connection.php");
  
 ?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Order List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                   <th>S.No</th>
                  <!-- <th>Product_Id</th> -->
                  <th>Product_Id</th>
                  <th>Product_Name</th>
                  <th>Quantity</th>
                  <th>Unit_Price</th>
                   <th>Payment_Id</th>
                  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                  <?php
               
                 $sql="select * from tbl_order";
                 $result=mysqli_query($con,$sql);
                   $sno=1;
                 while($row=mysqli_fetch_assoc($result))
               {
                  ?>
              
                <tr>
                  <td><?= $sno++;?></td>
               
                  <td><?php echo $row['product_id'];?></td>
                  <td><?php echo $row['product_name'];?></td>
                <td><?php echo $row['quantity'];?></td>
                <td><?php echo $row['unit_price'];?></td>
                <td><?php echo $row['payment_id'];?></td>
                
                 <!-- td><a href="?id=<?=base64_encode($row['id'])?>"><i class="fa fa-pencil" style="font-size:20px"></i>
              </a></td>  -->
      <td>
       <a href="?del=<?php echo $row['id'];?>"onclick="return confirm('Are you sure You want to delete this record')"><i class="fa fa-trash-o" style="font-size:20px"></i></td>    
     
                  
                </tr>
                <?php
              }
                ?>
                
                </tbody>
               
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql="delete from tbl_order where id='$id'";
$query=mysqli_query($con,$sql);
if($query)
{
  ?>
  <script>
   alert("Record Deleted Successfully..!!!");
    window.location= "order_list.php";
  </script>
  <?php
}

}

 ?>