   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
include_once("connection.php");
//  session_start();
//  if($_SESSION['id'] != 1){
//     ?>
//   <script>
// 		window.location= "adminlogin.php";
// 		alert("please login first");
// 		</script>  
// <?php
// }  
 ?>
 
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ADD PRODUCT  NAME</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
      <form  method="POST" action="" enctype="multipart/form-data">

              <div class="box-body">
                <!-- <div class="form-group">
                  <label for="pcategory">Product Category</label>
                  <input type="text" class="form-control"  name="pcategory" id="pcategory" >
                </div> -->

        <div class="box-body">
           <div class="form-group">
        <label for="pcategory">product_category</label>
        <select id="pcategory"  name="pcategory" class="form-control" type="text" >
        <option value="">--Category Name--</option>
                <?php
          $sql="select category_id,product_category from product_category";
          $query=mysqli_query($con,$sql);
         while($row=mysqli_fetch_assoc($query))
                     { ?>
          <option value="<?php echo $row['category_id'];?>"><?php echo $row['product_category'];?></option>
                     <?php } ?>  
                    </select>
                       </div>
                 </div>

<div class="box-body">
           <div class="form-group">
        <label for="psubcategory">product_subcategory</label>
        <select id="psubcategory"  name="psubcategory" class="form-control"  type="text" >
        <option value=" ">--subCategory Name--</option>
                <?php
          $sql="select subcategory_id,product_subcategory from product_subcategory";
          $query=mysqli_query($con,$sql);
         while($row=mysqli_fetch_assoc($query))
                     { ?>
          <option value="<?php echo $row['subcategory_id'];?>"><?php echo $row['product_subcategory'];?></option>
                     <?php } ?>  
                    </select>
                       </div>
                 </div>

               <div class="form-group">
                  <label for="pname">Product Name</label>
                  <input type="text" class="form-control"  name="pname" id="pname"  >
                </div>
                <!--  <div class="form-group">
                  <label for="pdetail">Product detail</label>
                  <input type="text" class="form-control"  name="pdetail" id="pdetail" >
                </div> -->
          <div class="form-group">
            <label for="pdetail">Product detail</label>
            <textarea name="editor">Enter Your Content Here</textarea>
         </div>

               <div class="form-group">
                  <label for="pprice">Product Price</label>
                  <input type="text" class="form-control"  name="pprice" id="pprice"  >
                </div>
                 <div class="form-group">
                  <label for="pcategory">Picture upload</label>
                  <input type="file" class="form-control"  name="image" id="picture"  >
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div> 
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php

if(isset($_POST['submit']))
{
    
$pcategory=$_POST['pcategory'];
$psubcategory=$_POST['psubcategory'];
$pname=$_POST['pname'];
$pdetail=$_POST['editor'];
$pprice=$_POST['pprice'];

 $img= $_FILES['image']["name"];
 $bannerpath=SITE_ROOT."/upload_data/".$img;
 $data = move_uploaded_file($_FILES["image"]["tmp_name"],$bannerpath); 
  
 if ($data == 1) {
  $sql="insert into product_name(category_id, subcategory_id,product_name,product_detail,product_price,product_image) values ('$pcategory','$psubcategory','$pname','$pdetail','$pprice','$img')";
$query=mysqli_query($con,$sql);

if ($query){?>
<script>
  alert("product added successfully!!!");
</script>
  <?php }
 }else{

  alert("Some problem Occur!!!");
 
 }

}
 ?>