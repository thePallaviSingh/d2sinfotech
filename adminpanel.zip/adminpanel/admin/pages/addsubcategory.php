   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
 ?>
 <?php
 include_once("connection.php");
//  session_start();
//  if($_SESSION['id'] != 1){
//     ?>
//   <script>
// 		window.location= "adminlogin.php";
// 		alert("please login first");
// 		</script>  
// <?php
// }  
 ?>


<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ADD SUBCATEGORY</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
      <form id='frm1' method="POST" action="" enctype = "multipart/form-data">

              <div class="box-body">
                <!-- <div class="form-group">
                  <label for="pcategory">Product Category</label>
                  <input type="text" class="form-control"  name="pcategory" id="pcategory" >
                </div> -->

        <div class="box-body">
           <div class="form-group">
        <label for="pcategory">product_category</label>
        <select id="pcategory"  name="pcategory" class="form-control"  required type="text" >
        <option value=" ">--Category Name--</option>
                <?php
          $sql="select category_id,product_category from product_category";
          $query=mysqli_query($con,$sql);
         while($row=mysqli_fetch_assoc($query))
                     { ?>
          <option value="<?=$row['category_id'];?>"><?=$row['product_category'];?></option>
                     <?php } ?>  
                    </select>
                       </div>
                 </div>
               <div class="form-group">
                  <label for="pcategory">Product SubCategory</label>
                  <input type="text" class="form-control"  name="psubcategory" id="psubcategory" required >
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div> 
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php
if(isset($_POST['submit']))
{
$pcategory=$_POST['pcategory'];
$psubcategory=$_POST['psubcategory'];

$sql="insert into product_subcategory(category_id,product_subcategory) values ('$pcategory','$psubcategory')";
$query=mysqli_query($con,$sql);
if ($query)
{
  ?>
<script>
  alert("record added successfully!!!");
</script>
  <?php
}
}
 ?>