   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
  include_once("connection.php");
   session_start();
 if($_SESSION['id'] != 1){
    ?>
  <script>
		window.location= "adminlogin.php";
		alert("please login first");
		</script>  
<?php
}  
 ?>
<?php
$id= $_GET['id'];
$sql="select * from product_subcategory where subcategory_id='$id'";
$query=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($query);
?>

<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ADD SUBCATEGORY</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
      <form id='frm' method="POST" action="" enctype = "multipart/form-data">

              <div class="box-body">
                <!-- <div class="form-group">
                  <label for="pcategory">Product Category</label>
                  <input type="text" class="form-control"  name="pcategory" id="pcategory" >
                </div> -->
        <div class="box-body">
           <div class="form-group">
        <label for="pcategory">product_category</label>
        <select id="pcategory"  name="pcategory" class="form-control"  required type="text" >
        <option value="product_id">--Category Name--</option>
                <?php
                $id=$_GET['id'];
          $sql="select category_id,product_category from product_category";
          $query=mysqli_query($con,$sql);
         while($row1=mysqli_fetch_assoc($query))
                     { ?>
          <option value="<?php echo $row1['category_id'];?>" <?php if($row1['category_id'] == $row['subcategory_id']){ echo 'selected';}?>><?php echo $row1['product_category'];?></option>
                     <?php } ?>  
                    </select>
                       </div>
                 </div>
               <div class="form-group">
                  <label for="pcategory">Product SubCategory</label>
                  <input type="text" class="form-control" name="psubcategory" id="psubcategory" value="<?php echo $row['product_subcategory'];?>" >
                </div>
                 <div class="form-group">
                  <label for="pcategory">Picture upload</label>
                  <input type="file" class="form-control"  name="image" id="picture" >
                </div>
                <div class="form-group">
                <label for="pcategory">image</label>
              <div class="form-group">
              <?php if(!empty($row['sub_categoryimage'])):?>
          <img src="pic/<?=$row['sub_categoryimage'];?>" alt="" style="width:100px;height:100px; border-radius: 50%;">
           <?php else:?>
             <img src="pic/no-image.jpg" alt="" style="width:100px;height:100px; border-radius: 50%;">
            <?php endif; ?>
                </div>
                </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit"  name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div> 
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php
if(isset($_POST['submit']))
{
$id=$_GET['id'];
$pcategory=$_POST['pcategory'];
$psubcategory=$_POST['psubcategory'];
$image=$_FILES['image']['name'];
$image_temp=$_FILES['image']['tmp_name'];
move_uploaded_file($image_temp,"pic/$image");
if($image=="")
    {
    $sql="update product_subcategory set  category_id='$pcategory',product_subcategory='$psubcategory'where subcategory_id='$id'";
  $query=mysqli_query($con,$sql);
  if($query)
  {
      ?>
      <script>
    alert("subcategory are  updated successfully!!!");
    </script>
    <?php
}
  else
  {
  ?>
  <script>
   alert("subcategory  are  not updated successfully!!!");
  </script>
  <?php
  } 
}
    else{
$sql="update product_subcategory set  category_id='$pcategory',product_subcategory='$psubcategory', sub_categoryimage='$image'  where subcategory_id='$id'";
  $query=mysqli_query($con,$sql);

     if($query)
{
  ?>  
    <script>
    alert("subcategory updated successfully!!!");
    </script>
    <?php
}
  else{?>
  <script>
   alert("subcategory are  not updated successfully!!!");
  </script>
  <?php
  }
}
}
 ?>
