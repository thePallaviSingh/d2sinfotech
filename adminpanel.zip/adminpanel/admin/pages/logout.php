<!-- <?php
//session_destroy();
//header("location:adminlogin.php");
?> -->
<?php 
ob_start();
session_start(); 
unset($_SESSION['customer']);
header("location:adminlogin.php");
?>