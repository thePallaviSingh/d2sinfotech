   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
  include_once("connection.php");
   
 ?>
 <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script> 
<?php
$id= $_GET['id'];
$sql="select * from product_name where id='$id'";
$query=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($query);
?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ADD PRODUCT  Name</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
      <form id='frm1' method="POST" action="" enctype = "multipart/form-data">

           <div class="box-body">
         <div class="box-body">
           <div class="form-group">
        <label for="pcategory">product_category</label>
        <select id="pcategory"  name="pcategory" class="form-control"   type="text" >
        <option value="product_id">--Category Name--</option>
                <?php
                $id=$_GET['id'];
          $sql="select category_id,product_category from product_category";
          $query=mysqli_query($con,$sql);
         while($row1=mysqli_fetch_assoc($query))
                     { ?>
          <option value="<?php echo $row1['category_id'];?>" <?php if($row1['category_id'] == $row['category_id']){ echo 'selected';}?>><?php echo $row1['product_category'];?></option>
                     <?php } ?>  
                    </select>
                       </div>
                 </div>

     <div class="box-body">
           <div class="form-group">
        <label for="psubcategory">product_subcategory</label>
        <select id="psubcategory"  name="psubcategory" class="form-control"   type="text" >
        <option value="product_id">--subCategory Name--</option>
                <?php
          $sql="select subcategory_id,product_subcategory from product_subcategory";
          $query=mysqli_query($con,$sql);
         while($subcatrow=mysqli_fetch_assoc($query))
                     { ?>
 <option value="<?php echo $subcatrow['subcategory_id'];?>" <?php if($subcatrow['subcategory_id'] == $row['subcategory_id']){ echo 'selected';}?>><?php echo $subcatrow['product_subcategory'];?></option>

        <!--   <option value="<?php echo $subcatrow['subcategory_id'];?>"><?php echo $row['product_subcategory'];?></option> -->
                     <?php } ?>  
                    </select>
                       </div>
                 </div>
               <div class="form-group">
                  <label for="pname">Product Name</label>
                  <input type="text" class="form-control"  value="<?php echo $row['product_name'];?>" name="pname" id="pname" >
                </div>
                 
             <div class="form-group">
            <label for="pdetail">Product detail</label>
            <textarea name="editor"><?php echo $row['product_detail'];?></textarea>
         </div>


               <div class="form-group">
                  <label for="pprice">Product Price</label>
                  <input type="text" class="form-control"  value="<?php echo $row['product_price']; ?>" name="pprice" id="pprice" >
                </div>


                 <div class="form-group">
                  <label for="pcategory">Picture upload</label>
                  <input type="file" class="form-control"  name="image" id="picture" >
                </div>

                 <div class="form-group">
                <label for="pcategory">image</label>
              <div class="form-group">
              <?php if(!empty($row['product_image'])):?>
          <img src="<?=img_ROOT."upload_data/".$row['product_image']?>" alt="" style="width:100px;height:100px; border-radius: 50%;">
           <?php else:?>
             <img src="pic/no-image.jpg" alt="" style="width:100px;height:100px; border-radius: 50%;">
            <?php endif; ?>
                </div>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div> 
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
<?php
if(isset($_POST['submit']))
{
$id=$_GET['id'];
$pcategory=$_POST['pcategory'];
$psubcategory=$_POST['psubcategory'];
$pname=$_POST['pname'];
$pdetail=$_POST['editor'];
$pprice=$_POST['pprice'];
$image=$_FILES['image']['name'];
$image_temp=$_FILES['image']['tmp_name'];
 $bannerpath=SITE_ROOT."/upload_data/".$img;
move_uploaded_file($_FILES["image"]["tmp_name"],$bannerpath); 
if($image=="")
    {
     $sql="update product_name set  category_id='$pcategory',subcategory_id='$psubcategory',product_name='$pname',product_detail='$pdetail',product_price='$pprice' where id='$id'";
 
  $query=mysqli_query($con,$sql);
  if($query)
  {
      ?>
      <script>
    alert("subcategory are  updated successfully!!!");
    </script>
    <?php
}
  else
  {
  ?>
  <script>
   alert("subcategory  are  not updated successfully!!!");
  </script>
  <?php
  } 
}
    else{
 $sql="update product_name set  category_id='$pcategory',subcategory_id='$psubcategory',product_name='$pname',product_detail='$pdetail',product_price='$pprice', product_image='$image' where subcategory_id='$id'";
  $query=mysqli_query($con,$sql);

     if($query)
{
  ?>  
    <script>
    alert("subcategory updated successfully!!!");
    </script>
    <?php
}
  else{?>
  <script>
   alert("subcategory are  not updated successfully!!!");
  </script>
  <?php
  }
}
}
 ?>
 