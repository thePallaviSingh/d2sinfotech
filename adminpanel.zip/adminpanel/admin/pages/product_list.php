<?php
include '../layouts/css.php';
include '../layouts/header.php';
include '../layouts/sidebar.php';
include_once("connection.php");

?>
<div class="content-wrapper">
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="box">
<div class="box-header">
<h3 class="box-title">VIEW PRODUCT</h3>
</div>
<!-- /.box-header -->
<div class="box-body">
<table id="example1" class="table table-bordered table-striped">
<thead>
<tr>
  <th>S.No</th>
  <th>category name</th>
 <th>subcategory name</th>
  <th>Product Name</th>
  <th>product detail</th>
  <th>product price</th>
  <th>Image</th>
  <th>Status</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>
</thead>
<tbody>
  <?php
  
  $sql="select product_name.id,product_name.status, product_category.product_category,product_subcategory.product_subcategory,product_name.product_name,product_name.product_detail,product_name.product_price,product_name.product_image from ((product_name inner join product_subcategory on product_name.subcategory_id=product_subcategory.subcategory_id)INNER JOIN product_category on product_name.category_id=product_category.category_id) where status='1'";
 $result=mysqli_query($con,$sql);
   $sno=1;
 while($row=mysqli_fetch_assoc($result))
{
  ?>

<tr>
   <td><?= $sno++;?></td>
   <td><?php echo $row['product_category'];?></td>
  <td><?php echo $row['product_subcategory'];?></td>
  <td><?php echo $row['product_name'];?></td>
  <td><?php echo $row['product_detail'];?></td>
  <td><?php echo $row['product_price'];?></td> 
  <td> <img src="<?=img_ROOT."upload_data/".$row['product_image']?>" style="width: 64px;" class="img-responsive" alt="Avatar"> </td>

   <?php
  if($row['status']=='1') {
       ?>
 <td><i data="<?php echo $row['id'];?>" class="status_checks btn
  <?php echo ($row['status']== 1)?
  'btn-danger': 'btn-success'?>"><?php echo ($row['status'] == 1)? 'Inactive' : 'Active'?>
  <?php
    }   
 ?>
 </i></td>

  <td><a href="product_nameupdate.php?id=<?php echo $row['id'];?>"><i class="fa fa-pencil" style="font-size:20px"></i>
</a></td> 

<td>
<a href="product_list.php?del=<?php echo $row['id'];?>" onclick="return confirm('Are you sure You want to delete this record')"><i class="fa fa-trash-o" style="font-size:20px"></i></td>  
</tr>
<?php
}
?>
</tbody>
</table>
</div>
<!-- /.box-body -->
</div>
</div>
</div>

<script>
    $(document).ready(function(){
        $("#example1").dataTable();
    });
     $(document).on('click','.status_checks',function(){
      var status = ($(this).hasClass("btn-success")) ? '0' : '1';
      var msg = (status=='0')? 'Deactivate' : 'Activate';
      if(confirm("Are you sure to "+ msg)){
        var current_element = $(this);
        url = "ajax_inactive.php";
        $.ajax({
          type:"POST",
          url: url,
          data: {id:$(current_element).attr('data'),status:status},
          success: function(data)
          {   
            location.reload();
          }
        });
      }      
    });
</script>

</section>
</div>
<?php
include '../layouts/footer.php';
?>
<?php
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql="delete from product_name where id='$id'";
$query=mysqli_query($con,$sql);
if($query)
{
?>
<script>
alert("Record Deleted Successfully..!!!");
window.location="product_list.php";
</script>
<?php
}
}
?>