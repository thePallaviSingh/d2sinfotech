<?php
include '../layouts/css.php';
include '../layouts/header.php';
include '../layouts/sidebar.php';
include_once("connection.php");
?>
<div class="content-wrapper">
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="box">
<div class="box-header">
<h3 class="box-title">VIEW SUBCATEGORY</h3>
</div>
<!-- /.box-header -->
<div class="box-body">
<table id="example1" class="table table-bordered table-striped">
<thead>
<tr>
  <th>S.No</th>
 <!--  <th>product_Id</th> -->
  <th>Category Name</th>
  <th>SubCategory Name</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>
</thead>
<tbody>
  <?php
 $sql="SELECT subcategory_id,product_subcategory,product_subcategory.category_id,product_category.product_category FROM product_subcategory INNER JOIN product_category ON product_subcategory.category_id=product_category.category_id";
 $result=mysqli_query($con,$sql);
  $sno=1;
 while($row=mysqli_fetch_assoc($result))
{
  ?>

<tr>
   <td><?= $sno++;?></td>
 <!--  <td><?php echo $row['subcategory_id'];?></td> -->
  <td><?php echo $row['product_category'];?></td>
   <td><?php echo $row['product_subcategory'];?></td>

 <td><a href="subcategoryupdate.php?id=<?php echo $row['subcategory_id'];?>"><i class="fa fa-pencil" style="font-size:20px"></i>
</a></td> 
<td>
<a href="viewsubcategory.php?del=<?php echo $row['subcategory_id'];?>" onclick="return confirm('Are you sure You waant to delete this record')"><i class="fa fa-trash-o" style="font-size:20px"></i>        </td>   
</tr>
<?php
}
?>

</tbody>

</table>
</div>
<!-- /.box-body -->
</div>

</div>
</div>
</section>
</div>
<?php
include '../layouts/footer.php';
?>
<?php
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql="delete from product_subcategory where subcategory_id='$id'";
$query=mysqli_query($con,$sql);
if($query)
{
?>
<script>
alert("Record Deleted Successfully..!!!");
window.location= "viewsubcategory.php";
</script>
<?php
}

}

?>