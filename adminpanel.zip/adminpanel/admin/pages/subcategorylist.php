   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
 ?>
<?php
include_once("connection.php");
?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">VIEW PRODUCT</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>category_Id</th>
                  <th>Category Name</th>
                  <th>SubCategory Name</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                 $sql="select * from product_subcategory";
                 $result=mysqli_query($con,$sql);
                 while($row=mysqli_fetch_assoc($result))
               {
                  ?>
              
                <tr>
                  <td><?php echo $row['category_id'];?></td>
                  <td><?php echo $row['product_category'];?></td>
                   <td><?php echo $row['product_subcategory'];?></td>
                 <td><a href="productupdate.php?id=<?php echo $row['category_id'];?>"><i class="fa fa-pencil" style="font-size:20px"></i>
              </a></td> 
             <td>
       <a href="viewproduct.php?del=<?php echo $row['category_id'];?>" onclick="return confirm('Are you sure You waant to delete this record')"><i class="fa fa-trash-o" style="font-size:20px"></i>        </td>    
     
                  
                </tr>
                <?php
              }
                ?>
                
                </tbody>
               
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql="delete from product where product_id='$id'";
$query=mysqli_query($con,$sql);
if($query)
{
  ?>
  <script>
   alert("Record Deleted Successfully..!!!");
    window.location= "viewproduct.php";
  </script>
  <?php
}

}

 ?>