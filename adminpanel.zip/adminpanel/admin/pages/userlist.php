   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
  include_once("connection.php");
  
 ?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">User List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                   <th>S.No</th>
                  <!-- <th>Product_Id</th> -->
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Country</th>
                   <th>Address</th>
                <th>City</th>
                   <th>State</th>
                    <th>Zip</th>
                 <th>Token</th>
                    <th>Time</th>
                  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                  $id=$_GET['cust_id'];
                 $sql="select * from tbl_customer";
                 $result=mysqli_query($con,$sql);
                   $sno=1;
                 while($row=mysqli_fetch_assoc($result))
               {
                  ?>
              
                <tr>
                  <td><?= $sno++;?></td>
               
                  <td><?php echo $row['cust_name'];?></td>
                  <td><?php echo $row['cust_email'];?></td>
                <td><?php echo $row['cust_phone'];?></td>
                <td><?php echo $row['cust_country'];?></td>
                <td><?php echo $row['cust_address'];?></td>
                <td><?php echo $row['cust_city'];?></td>
                <td><?php echo $row['cust_state'];?></td>
            <td><?php echo $row['cust_zip'];?></td>
                <td><?php echo $row['cust_token'];?></td>
                <td><?php echo $row['cust_timestamp'];?></td>
                 <!-- td><a href="?id=<?=base64_encode($row['cust_id'])?>"><i class="fa fa-pencil" style="font-size:20px"></i>
              </a></td>  -->
      <td>
       <a href="?del=<?php echo $row['cust_id'];?>"onclick="return confirm('Are you sure You want to delete this record')"><i class="fa fa-trash-o" style="font-size:20px"></i></td>    
     
                  
                </tr>
                <?php
              }
                ?>
                
                </tbody>
               
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php
if(isset($_GET['del']))
{
$id=$_GET['del'];
$sql="delete from tbl_customer where cust_id='$id'";
$query=mysqli_query($con,$sql);
if($query)
{
  ?>
  <script>
   alert("Record Deleted Successfully..!!!");
    window.location= "userlist.php";
  </script>
  <?php
}

}

 ?>