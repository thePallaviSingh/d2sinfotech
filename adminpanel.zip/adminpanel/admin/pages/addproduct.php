   <?php
  include '../layouts/css.php';
  include '../layouts/header.php';
  include '../layouts/sidebar.php';
 session_start();
if($_SESSION['id'] != 1){
?>
<script>
window.location= "adminlogin.php";
alert("please login first");
</script>
<?php
}
?>
 
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ADD CATEGORY</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
 <form id='frm1' method="POST"  action="">

          
              <div class="box-body">
                <div class="form-group">
                  <label for="pcategory">Product Category</label>
                  <input type="text" class="form-control"  name="pcategory" id="pcategory" required >
                </div>
   
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div> 
      </div>
    </div>
  </section>
</div>
<?php
   include '../layouts/footer.php';
 ?>
 <?php
if(isset($_POST['submit']))
{
$pcategory=$_POST['pcategory'];
$sql="insert into product_category (product_category)values ('$pcategory')";
$query=mysqli_query($con,$sql);
if ($query)
{
  ?>
<script>
  alert("record added successfully!!!");
</script>
  <?php
}
}
 ?>