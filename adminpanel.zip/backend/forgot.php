<?php
include_once("connection.php");
?>
<?php
 
 if(isset($_POST['forgotpwd'])) {
        
    if(empty($_POST['email'])) {
        
    } else {
        
        $cust_email = strip_tags($_POST['email']); 
        $query="select * from tbl_customer where cust_email='".$cust_email."'";
         $q=mysqli_query($con,$query) or die(mysqli_error($con));
        foreach($q as $row) {
            $cust_status = $row['cust_status'];
            $row_email = $row['cust_email'];
            $row_token = $row['cust_token'];
            $cust_name = $row['cust_name'];
        }  
                if($cust_email != $row_email) {
                    echo "<script>alert('Email id Not Found !')</script>";
                     
       } else { 
           $data =['tokenKey' => $row_token,
                    'otp' => random_number(4),
                    'status'=> 0
                  ];    
            $sql ="INSERT INTO `tbl_reset`(usertoken,otp,status) VALUES ('".$data['tokenKey']."','".$data['otp']."','".$data['status']."')";
            $query=mysqli_query($con,$sql);
           if($query == 1){
              $to= $row_email; 
               $subject = 'PASSWORD RESET REQUEST -  D2S Infotech';
                $message = '<p>Hello,'.$cust_name.' <br>To reset your password, please click on the link below<br> 
                <a class="btn btn-success" href="https://loopintechies.com/d2epson2/pages/resetpassword.php?tokenkey='.$data['tokenKey'].'&otp='.$data['otp'].'">Click here</a>';
               
                $header = "From: noreply@d2sinfotech.in\r\n" .
                   "Reply-To: noreply@d2sinfotech.in\r\n" .
                   "X-Mailer: PHP/" . phpversion() . "\r\n" . 
                   "MIME-Version: 1.0\r\n" . 
                   "Content-Type: text/html; charset=ISO-8859-1\r\n";
	
                       $retval = mail ($to,$subject,$message,$header);
                        if($retval == 1)
                          {
                          ?>
                          <script>
                          alert("Please Check Mail TO Change Passsword !!!");
                          </script>
                          <?php
                          } 
                          
           }
      } 
    }

}
function random_number($digits = ''){
    return rand(pow(10, $digits-1), pow(10, $digits)-1);
}
?>