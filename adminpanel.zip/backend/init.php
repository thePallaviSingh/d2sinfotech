<?php
ob_start();
session_start();
include_once("connection.php");         
date_default_timezone_set('Asia/Kolkata');         
?>
<?php
if(empty($_POST['amount'])) {
		header('location: ../pages/checkout.php');
	} else {
		$payment_date = date('Y-m-d H:i:s');
	    $payment_id = time();
	       $statement = "INSERT INTO `tbl_payment`(customer_id,customer_name,customer_email,payment_date,txnid,paid_amount,payment_method,payment_status,shipping_status,payment_id) VALUES ('".$_SESSION['customer']['cust_id']."','".$_SESSION['customer']['cust_name']."','".$_SESSION['customer']['cust_email']."','".$payment_date."','','".$_POST['amount']."','COD','Pending','Pending','".$payment_id."')";
	       $statementresult=mysqli_query($con,$statement); 
	        if ($statementresult == 1) {  
                    	foreach($_SESSION['cart'] as $key => $value) 
					    {
				          $order = "INSERT INTO `tbl_order`(product_id,
				         product_name,
				         quantity,
				         unit_price,
				         payment_id) VALUES ('".$value['product_id']."','".$value['item_name']."','".$value['item_quantity']."','".$value['product_price']."','".$payment_id."')";
					    $result=mysqli_query($con,$order); 
					     
					    }
					    if ($result == 1) {
					    	unset($_SESSION['cart']);
					        header('location: ../pages/payment_success.php');
					    }
			}
	    
	     }
	


?>


