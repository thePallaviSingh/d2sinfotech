<?php
include_once("connection.php");
session_start();
?>
<?php
 


 if(isset($_POST['submit'])) {
        
    if(empty($_POST['email']) || empty($_POST['password'])) {
        
    } else {
        
        $cust_email = strip_tags($_POST['email']);
        $cust_password = strip_tags($_POST['password']);
        $query="select * from tbl_customer where cust_email='".$cust_email."' and cust_password='".$cust_password."'";
         $q=mysqli_query($con,$query) or die(mysqli_error($con));
        foreach($q as $row) {
            $cust_status = $row['cust_status'];
            $row_password = $row['cust_password'];
        }  
                if($cust_status == 0) {
                    echo "<script>alert('please Verify Your Account !  Then Try Login')</script>";
                     
                                     } else {
                    $_SESSION['customer'] = $row;
                    
                    header("location: ../pages/myaccount.php");
                } 
    }
}
?>
