<?php
$host="localhost";
$username="epson_infotech";
$password="epson_infotech";
$db="epson_infotech";
$con=mysqli_connect($host,$username,$password,$db);
?>
